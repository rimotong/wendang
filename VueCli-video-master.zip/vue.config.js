// vue.config.js
const path = require('path')
const webpack = require('webpack')
function resolve(dir) {  
  return path.join(__dirname, dir)  
}  
 
module.exports = {
//  baseUrl: process.env.NODE_ENV === 'production' ? '/bcmp-web/' : '/',
//  outputDir: process.env.NODE_ENV === 'production' ? 'bcmp-web' : 'dist',
 lintOnSave: true,
 productionSourceMap: false,
 devServer: {
  open: true,
  host: '0.0.0.0',
  port: 9005,
  https: false,
  hotOnly: false,
  proxy: null
 },
 configureWebpack: {  
  resolve: {
    extensions: ['.js', '.vue', '.json'],
    alias: {
      '@': resolve('src'),
      'assets': resolve('src/assets'),
      'components': resolve('src/components'),
      'views': resolve('src/views'),
    },
  },
  plugins: [
   new webpack.ProvidePlugin({
    jQuery: 'jquery',
    $: 'jquery',
    'windows.jQuery': 'jquery'
   })
  ]
 },
 chainWebpack: config => {
  const fileRule = config.module.rule('file')
  fileRule.uses.clear()
  fileRule
    .test(/\.pdf|ico$/)
    .use('file-loader')
    .loader('file-loader')
    .options({
        limit: 10000,
    })
  config.module
   .rule('swf')
   .test(/\.swf$/)
   .use('url-loader')
   .loader('url-loader')
   .options({
    limit: 10000
   })
   //使用本地svg
   config.module
   .rule('svg')
   .exclude.add(resolve('src/icons'))       //注意svg的存储地址
   .end()
   config.module
   .rule('icons')
   .test(/\.svg$/)
   .include.add(resolve('src/icons'))        //注意svg的存储地址
   .end()
   .use('svg-sprite-loader')
   .loader('svg-sprite-loader')
   .options({
     symbolId: 'icon-[name]'
   })
   .end()
 },
 pluginOptions: {
  'style-resources-loader': {
   preProcessor: 'scss',
   patterns: [
    path.resolve(__dirname, './src/assets/baseStyle/var.scss'),
    path.resolve(__dirname, './src/assets/baseStyle/mixin.scss')
   ]
  }
 }
}