var api = api || {};

api.baseUrl = "http://192.168.1.189:3000"   // 请求地址

api.monmsg = "网络遇到问题,请重试!";

api.loign = "/api/loign"  // 登录

export { api };