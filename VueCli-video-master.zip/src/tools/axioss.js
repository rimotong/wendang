import sevice from "./network"
import axios from 'axios';

export default {
    get: function (path = '', data = {}) {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "GET",
                params: data
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response.data);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    gets: function (path = '', data = {}) {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "GET",
                data: data
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response.data);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    getss: function (path = '') {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "GET",
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    getses: function (path = '') {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "GET",
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    postjson: function (path = '', data = {}) {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "POST",
                headers: {
                    'Content-Type': 'application/json'
                },
                data: data
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    post: function (path = '', data = {}) {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "POST",
                data: data
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response.data);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    postes: function (path = '', data = {}) {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "POST",
                data: data
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    postformdata: function (path = '', data = {}) {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "POST",
                headers: {
                    "Content-Type": "multipart/form-data",
                },
                data: data
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response.data);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    posts: function (path = '') {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "POST",
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response.data);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    poss: function (path = '', data = {}) {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "POST",
                data: data
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    postplural: function (path = '') {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "POST",
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    put: function (path = '', data = {}) {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "PUT",
                params: data
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response.data);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    },
    puts: function (path = '') {
        return new Promise(function (resolve, reject) {
            sevice.request({
                url: path,
                method: "PUT",
            })
                .then(function (response) {
                    // 按需求来，这里我需要的是response.data，所以返回response.data，一般直接返回response
                    resolve(response.data);
                })
                .catch(function (error) {
                    reject(error);
                });
        });
    }
}