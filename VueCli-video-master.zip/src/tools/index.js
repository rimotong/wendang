// 导入封装好的网络请求类工具
import Axioss from './axioss';
import qs from 'qs'
// 封装各种接口请求
// export const 接口名 = () => Network.get('/路由',参数对象); 
var urls=1;
var url="";
if(urls==0){
	url='/api-purchase';
}else{
	url="";
}
const baseURL = 'http://10.139.198.227:9537'
var	testurl8 = "/login" //权限

//index
//直播类型-1在线设备,2计划分组
export function getFLVList(parms){
	return Axioss.post(`getFLVList`,parms)
}
//查询录制视频列表
export function getFileVideos(parms){
	return Axioss.get(`getFileVideos`,parms)
}
//开始录制
export function videoRecordStart(flvPath,tvId,fileName){
	return Axioss.get(`/videoRecordStart/${flvPath}/${tvId}/${fileName}`)
}
//结束录制
export function videoRecordStop(fileName,tvId){
	return Axioss.get(`/videoRecordStop?fileName=${fileName}&id=${tvId}`)
}

export function flv(parms){
	return Axioss.get(`/live/${parms}/live.flv`)
}
//删除录制视频
export function deleteFileVideos(fileId){
	return Axioss.post(`/deleteFileVideos/${fileId}`,)
}

//room
//10.139.199.16/mis/api-remoteAudit/virtualRoom/getVideoEvidenceGroup 
//10.139.199.16/mis/api-remoteAudit/virtualRoom/videoRecordBegin 开始录制
//视频列表
export function getVideoEvidenceGroup(parms){
	return Axioss.post(`/virtualRoom/getVideoEvidenceGroup`,parms)
}
//开始录制
export function videoRecordBegin(parms){
	return Axioss.post(`/virtualRoom/videoRecordBegin`,parms)
}
//结束录制
export function videoRecordFinish(parms){
	return Axioss.post(`/virtualRoom/videoRecordFinish`,parms)
}
//list
export function getUserVirtualRoom(parms){
	return Axioss.postes("/virtualRoom/getUserVirtualRoom",parms)
}
//图片上传
export function uploadFile(id,parms){
	return Axioss.postformdata(`/AuditEvidence/uploadFile?connectTableName=bg_direct_play_info&connectFieldName=bg_direct_play_id&tvId=${id}`,parms)
}
export function virtualFile(id,parms){
	return Axioss.postformdata(`/AuditEvidence/uploadFile?connectTableName=virtual_room_info&connectFieldName=virtual_room_id&tvId=${id}`,parms)
}
//图片查询
export function getScreenshot(parms){
	return Axioss.post(`/AuditEvidence/getScreenshot`,parms)
}
//上传
export function upload(parms){
	let requestConfig = {
		headers: {
		  "Content-Type": "multipart/form-data",
		},
	  };
	Axioss.postes("/virtualRoom/upload",requestConfig,parms)
}
//删除虚拟房间附件
export function deleteVirtualRoomFile(parms){
	let requestConfig = {
		headers: {
		  "Content-Type": "multipart/form-data",
		},
	  };
	Axioss.get(`/mis/api-remoteAudit/virtualRoom/deleteVirtualRoomFile`,requestConfig,parms)
}

//设备管理
//获取组织选项下拉选项
export function getDropDownOptions(parms){
	return Axioss.postes(`/equipment/getDropDownOptions`,parms)
}
//获取设备列表
export function getEquipmentInfoList(parms){
	return Axioss.poss(`/equipment/getEquipmentInfoList`,parms)
}
//模板下载
export function downloadTemplate(){
	return Axioss.get(`/equipment/downloadTemplate`)
}
//设备导入
export function uploadTemplate(parms){
	return Axioss.post(`/Equipment/uploadTemplate`,parms)
}
//保存、更新设备信息
export function saveOrUpdate(parms){
	return Axioss.postes(`/equipment/saveOrUpdate`,parms)
}
//删除设备
export function deleteAuditEquipment(parms){
	return Axioss.postjson(`/equipment/deleteAuditEquipment`,parms)
}
// export function deleteAuditEquipment(parms){
// 	return Axioss.post(`/equipment/deleteAuditEquipment`,parms)
// }


//System
//区域信息
export function getBGList(parms){
	return Axioss.get("/region/getBGList",parms)
}
//删除区域信息
export function deleteRegion(parms){
	return Axioss.post(`/region/deleteRegion/${parms}`)
}
//新增区域信息
export function saveRegion(parms){
	return Axioss.post(`/region/saveRegion`,parms)
}
//查询员工列表
export function selectUserAuditList(parms){
	return Axioss.post(`/user/selectUserAuditList`,parms)
}
//新增员工或修改员工角色
export function saveOrUpdateStaff(parms){
	return Axioss.postes(`/user/saveOrUpdateStaff`,parms)
}
export function selectOrgInfoList(parms){
	return Axioss.get(`/user/selectOrgInfoList`,parms)
}
export function getUserRole(parms){
	return Axioss.post(`/user/getUserRole`,parms)
}
//删除用户
export function deleteStaffInfo(parms){
	return Axioss.postes(`/user/deleteStaffInfo/${parms}`)
}
//工号查询信息
export function queryStaffInformation(parms){
	return Axioss.postes(`/user/queryStaffInformation`,parms)
}
//(停用-启用)角色
export function stopAuditRole(userOrgId,type){
	return Axioss.post(`/user/stopAuditRole/${userOrgId}/${type}`)
}
//role 根据角色Id删除角色
export function deleteRole(roleId){
	return Axioss.post(`/role/deleteRole/${roleId}`)
}
//获取角色权限
export function getRole(parms){
	return Axioss.get(`/role/getRole`,parms)
}
//新增角色
export function insertRole(parms){
	return Axioss.post(`/role/insertRole`,parms)
}
//获取角色信息
export function getRolePermission(){
	return Axioss.get(`/role/getRolePermission`)
}
// // 根据工号查询用户信息
// export function queryStaffInformations(params) {
// 	return Axioss.post(`${testurl2}/queryStaffInformation`, params);
// }
//查询权限
// export function getPerm(parms){
// 	return Axioss.post(`${testurl8}/getPerm`,parms)
// }
//注销登录
export function getlogout(){
	return Axioss.poss(`${testurl8}/logout`)
}