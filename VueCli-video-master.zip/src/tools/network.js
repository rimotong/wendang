// 导入axios
import axios from 'axios';
import { getToken } from './common'
import { Message } from 'element-ui'
// 进行一些全局配置
// 公共路由(网络请求地址)
// axios.defaults.baseURL = 'http://10.139.198.191:6801/requirement';
// 请求响应超时时间
axios.defaults.headers['authToken'] = `7HJ1lGsb5UER2hQHgU7/Og==`;
axios.defaults.timeout = 50000;
const baseURL1 = 'http://10.139.198.227:9537'
export let baseURLs
var UrL = 0
const platformToken = getToken()
if (UrL == 0) {
  baseURLs = 'http://10.139.198.227:9537'//本地2
  // baseURLs = 'http://10.139.199.16/mis/api-remoteAudit' //本地2
} else {
  baseURLs = 'http://10.125.129.6/ra'//测试
}
var urls = 0;
var urles = "";
if (urls == 0) {
  urles = '/api-purchase';
} else {
  urles = "";
}
//获取token
// export function auditToken() {}
//退出登录
export function getlogout() {
  axios({
    method: "post",
    url: `${baseURLs}/login/logout`,
    headers: {
      // "Content-Type": "multipart/form-data",
      // token: getToken(),
    },
  }).then((res) => {
      if(res.data.code==100){
        // setTimeout(window.location.replace(`http://10.124.131.79/#/login` + window.location.host), 2000);
      }
    });
}
// 创建axios实例
const service = axios.create({
  baseURL: baseURLs, // 请求的基本地址
  timeout: 15 * 1000, // 请求超时时间
  withCredentials: true // 允许携带cookie
})
// request拦截器
service.interceptors.request.use(config => {
  if (getToken()) {
    // axios({
    //   method: "get",
    //   url: `${baseURLs}/role/getRole`,
    //   params:{projId:37} //platformToken
    // }).then((res) => {});
    // config.headers['token'] = getToken()
  }else{
    
  }
  return config
}, error => {
  // Do something with request error
  console.error(error) // for debug
  return Promise.reject(error)
})
// respone拦截器
service.interceptors.response.use(
  response => {
    const res = response.data
    // 请求数据不成功,弹框提示
    if (res.code != 100 && res.code != 101) {
      // token过期code401,返回登录页
      if (res.code == 401) {
        Message({
          message: '登录信息过期，即将跳转登录页！',
          type: 'error',
          duration: 2 * 1000
        })
        // setTimeout(window.location.replace(`http://10.124.131.79/#/login` + window.location.host), 2000)
      } else {
        if (res.code != 501) {
          Message({
            message: res.message || '请求发生错误！',
            type: 'error',
            duration: 2 * 1000
          })
        } else if (res.code == 400) {
          // this.$message.error("您有一些字段未填写，请查证填写完整后进行提交");
          this.$message({
            message: "您有一些字段未填写，请查证填写完整后进行提交",
            type: "warning",
          })
        }
      }
      return Promise.reject(new Error(res.message || '请求发生错误！'))
    } else {
      // 请求成功
      if (res.code == 101) {
        Message({
          message: res.message || '操作成功',
          type: 'success'
        })
      }
      return res.data
    }
  },
  error => {
    Message({
      message: '请求服务器失败！',
      type: 'error'
    })
    return Promise.reject(error)
  }
)
export default service
