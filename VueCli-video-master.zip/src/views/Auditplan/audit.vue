<template>
  <div class="main">99999999</div>
</template>
<style lang="scss" scoped>
  .main{
    background: #061b3a;
  }
</style>