<template>
  <div class="table-parent">
    <div>{{TableData}}</div>
    <el-table
      :header-cell-style="{'text-align':'center'}"
      :cell-style="{'text-align':'center'}"
      :data="tableData"
      v-horizontal-scroll="'always'"
      class="table-box"
      >
      <el-table-column type="index" label="序号" width="80px"></el-table-column>
      <el-table-column
        prop="date"
        label="计划编号"
        width="auto">
        <template slot-scope="scope">
          <span v-if="scope.row.date" style="color:#3c92ed">{{scope.row.date}}</span>
          <span v-else style="color:#3c92ed">--</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="name"
        label="计划名称"
        width="auto">
      </el-table-column>
      <el-table-column
        prop="address"
        width="auto"
        label="稽核人">
      </el-table-column>
      <el-table-column
        label="计划状态"
        width="auto">
        <template slot-scope="scope">
          <span :class="[scope.row.stats==='待审核'?'finishing': scope.row.stats==='已通过'?'true': scope.row.stats==='已驳回'?'reject':'']">{{scope.row.stats}}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="auto">
        <template slot-scope="scope">
          <span @click="operate(scope.$index)" v-if="activeName=='first'">
            <svg-icon icon-class="caozuo" style="width: 2em;height: 2em;" />
          </span>
          <span v-else>
            <svg-icon icon-class="u216" style="width: 2em;height: 2em;" />
          </span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
export default {
  props:{
    TableData:{
      type:String,
      default:""
    },
    activeName:{
      type:String,
      default:""
    }
  },
  data() {
    return {
      tableData: [{
        stats:"草稿",
        date: '',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1518 弄'
      }, {
        stats:"待审核",
        date: '2016-05-04',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1517 弄'
      }, {
        stats:"已通过",
        date: '2016-05-01',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1519 弄'
      }, {
        stats:"已驳回",
        date: '2016-05-03',
        name: '王小虎',
        address: '上海市普陀区金沙江路 1516 弄'
      }]
    }
  },
  methods:{
    operate(index){
      console.log(this.tableData[index])
    }
  }
}
</script>
<style lang="scss" scoped>
.table-parent {
  width: 100%;
  height: 500px;
  overflow-x:scroll;
  scrollbar-width: thin;
}
.table-box{
  max-width: inherit;
  width: 100%;
}
.finishing{
  color: #ff8f53;
}
.true{
  color: #67c23a
}
.reject{
  color:#cb5e61
}
</style>