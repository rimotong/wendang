<template>
  <div class="auditlist">
    <div class="layout">
      <section class="section">
        <div class="font">稽核计划</div>
        <section class="child">
          <div>
            <p>计划编号</p>
            <el-input
              v-model="name"
              placeholder="输入名称关键字"
              style="width:200px;"
            >
            </el-input>
          </div>
          <div>
            <p>计划名称</p>
            <el-input
              v-model="name"
              placeholder="输入名称关键字"
              style="width:200px;"
            >
            </el-input>
          </div>
          <div>
            <p>计划状态</p>
            <el-select v-model="value" placeholder="请选择">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </div>
        </section>
        <div>
          <el-button type="primary" style="margin-top:15px">查询</el-button>
          <el-button type="info" style="margin-left:20px">重置</el-button>  
        </div>      
      </section>
      <el-drawer
        title="我是标题"
        size="826px"
        :visible.sync="drawer"
        :with-header="false">
        <div style="padding:20px"><span style="font-size:18px">稽核计划</span><label style="float: right;color:#409eff;line-height: 28px;">提交后自动生成编号</label></div>
        <div style="margin:0px 10px;padding:0; width:806px;height:3px;background-color:#d7d7d7;"></div>  
      </el-drawer>
      <div class="table">
        <div class="main" style="margin-top: 30px;">
          <!-- stretch //占满空间 -->
          <el-tabs v-model="activeName">
            <el-tab-pane label="草稿箱" name="first"><TableData v-if="activeName=='first'" :activeName="activeName" :TableData="'88'"></TableData></el-tab-pane>
            <el-tab-pane label="待审核" name="second"><TableData v-if="activeName=='second'" :TableData="'98'"></TableData></el-tab-pane>
            <el-tab-pane label="已通过" name="third"><TableData v-if="activeName=='third'" :TableData="'99'"></TableData></el-tab-pane>
            <el-tab-pane label="已驳回" name="fourth"><TableData v-if="activeName=='fourth'" :TableData="'66'"></TableData></el-tab-pane>
          </el-tabs>
          <el-button size='mini' class="button" @click="add"><svg-icon icon-class="添加_add" style="width: 1.5em;height: 1.5em;float: right;" /><div style="line-height: 1.5em;float: right;">新增</div></el-button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import TableData from './components/tableData.vue';
export default {
  data() {
    return {
      activeName: 'first',
      drawer:false,
      fromdata:{},
      state:null,
      tableDataIndex:null,
      pageSize:5,
      totalSize:null,
      currentPage:1,//当前页数
      name: 'value',
      options: [{
        value: '选项1',
        label: '黄金糕'
      }, {
        value: '选项2',
        label: '双皮奶'
      }, {
        value: '选项3',
        label: '蚵仔煎'
      }, {
        value: '选项4',
        label: '龙须面'
      }, {
        value: '选项5',
        label: '北京烤鸭'
      }],
      optionsChild:[],
      Park:'',
      value: '',
    };
  },
  components:{TableData},
  methods:{
    add(){
      this.drawer = true
    },
    Sure(dates,fettle){
      if(fettle == "add"){
        this.tableData.unshift(dates)
      }else{
        this.tableData[this.tableDataIndex] = dates
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.onSubmit()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.onSubmit()
    },
    edit(index){
      this.fromdata = JSON.parse(JSON.stringify(this.tableData[index]))
      this.state = "edit"
      this.tableDataIndex = index
    }
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-form-item__label {
  color: #ffffff;
}
::v-deep .el-tab-pane{
  width: 100%;
}
::v-deep .el-tabs__nav-scroll {
  margin-top: 20px;
}
::v-deep .el-drawer.rtl {
    background: #0f274c;
    // overflow-y: auto;
  }
::v-deep .el-tabs__item {
  padding: 0 10px;
  height: 40px;
  box-sizing: border-box;
  line-height: 40px;
  display: inline-block;
  list-style: none;
  font-size: 16px;
  font-weight: 100%;
  color: #ffffff;
  position: relative;
}
::v-deep #tab-second{color: #ff8f53;}
::v-deep #tab-third{color: #67c23a;}
::v-deep #tab-fourth{color: #f56c6c;}
::v-deep .el-pagination button {
  color: #C0C4CC;
  background-color: #FFF0;
  cursor: not-allowed;
}
::v-deep .el-pagination .btn-next, .el-pagination .btn-prev {
  background: center center no-repeat #FFF0;
  background-size: 16px;
  cursor: pointer;
  margin: 0;
  color: #C0C4CC;
}
::v-deep .el-button--info {
  color: #FFF;
  background-color: #90939900;
  border-color: #909399;
}
::v-deep .el-table,::v-deep .el-table tr,::v-deep .el-table td,::v-deep .el-table th {
    background-color: transparent!important;
    color: #fff;
}
::v-deep .el-input {
  position: relative;
  font-size: 14px;
  display: inline-block;
}
::v-deep .el-textarea__inner,::v-deep  .el-input__inner{
        background: transparent;
        color: #fff;
   }
::-webkit-scrollbar {
  width: 0 !important;height: 0;
} //隐藏谷歌浏览器滚动条
.pagination{
	justify-self: center;
	align-self: center;
  margin-top: 20px;
}
.auditlist{
  background-color: rgba(6, 27, 58, 1);
  width: 100%;
  color: azure;
  padding: auto;
  // overflow-y: auto;
  // scrollbar-width: thin;//火狐浏览器滚动条
  // .drawer{
  //   // width: 826px;
  //   // background: #0f274c;
  // }
  .layout{
    width: 80%;
    margin: auto;
    .section{
      // margin-top: 10px;
      height: 60px;
      .child{
        display: flex;
        div{
          padding-right: 20px;
        }
      }
      .font{
        line-height: 80px;
        font-size: 26px;
      }
    }
      .table{
        margin-top: 170px;
        height: 600px;
        background: #1b2636;
        border-radius: 15px 15px 15px 15px;
        .main{
          position: relative;
          width: 90%;
          margin: auto ;
          display: grid;
          .button{
            position: absolute;
            margin-top: 20px;
            right:10px;
            top:5px;
            background: rgba(88, 62, 62, 0);
            border: none;
            font-size: 16px;
            color: #409eff;
          }
        }
      }
  }
}
</style>