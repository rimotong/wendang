<template>
  <el-table
    :data="tableData"
    style="width: 100%;">
    <el-table-column
      label="楼栋"
      width="auto">
      <template slot-scope="scope">
        <div @click="jump(scope.$index)">{{scope.row.orgName}}</div>
      </template>
    </el-table-column>
    <el-table-column
      prop="virtualRoomSize"
      label="大小"
      width="180">
    </el-table-column>
    <el-table-column
      prop="updateDate"
      label="更新时间"
      width="180">
    </el-table-column>
  </el-table>
</template>

<script>
import {getUserVirtualRoom} from "@/tools/index"
import { mapState,mapActions } from 'pinia'
import storeId  from '@/store'
  export default {
    created(){
      if(this.Factory.orgId==undefined){
        this.$router.push("/index1")
      }
      let fileFormDatas = new FormData();
      fileFormDatas.append("pid",this.Factory.orgId)
      getUserVirtualRoom(
        fileFormDatas
      )
      .then((res)=>{
        this.tableData = res
      })
    },
    data() {
      return {
        tableData: [
        //   {
        //   date: '2016-05-02',
        //   name: 'E5',
        //   address: '上海市'
        // }, {
        //   date: '2016-05-04',
        //   name: 'C1',
        //   address: '金沙江路 1517 弄'
        // }, {
        //   date: '2016-05-01',
        //   name: 'B12',
        //   address: ' 1519 弄'
        // }, {
        //   date: '2016-05-03',
        //   name: 'D3',
        //   address: '普陀区'
        // }
        ]
      }
    },
    methods:{
      jump(index){
        this.$router.push(
          {path:"/index5"}
        );
        const store = storeId()
        store.$patch((state) => {
          state.building = {building:this.tableData[index].orgName,orgId:this.tableData[index].orgId}
          sessionStorage.setItem('building', state.Factory)
        })
      }
    },
  computed: {
    ...mapState(storeId, ['Factory','building']),
  }
  }
</script>
