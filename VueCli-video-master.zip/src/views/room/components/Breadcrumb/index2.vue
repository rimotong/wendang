<template>
  <el-table
    :data="tableData"
    style="width: 100%;">
    <el-table-column
      label="地区"
      width="auto">
      <template slot-scope="scope">
        <div @click="jump(scope.$index)">{{scope.row.orgName}}</div>
      </template>
    </el-table-column>
    <el-table-column
      prop="virtualRoomSize"
      label="大小"
      width="180">
    </el-table-column>
    <el-table-column
      prop="updateDate"
      label="更新时间"
      width="180">
    </el-table-column>
  </el-table>
</template>

<script>
import { mapState } from 'pinia'
import {getUserVirtualRoom} from "@/tools/index"
import storeId  from '@/store'
  export default {
    created(){
      if(this.Business.orgId==undefined){
        this.$router.push("/index1")
      }
      let fileFormDatas = new FormData();
      fileFormDatas.append("pid",this.Business.orgId)
      getUserVirtualRoom(
        fileFormDatas
      )
      .then((res)=>{
        this.tableData = res
      })
    },
    data() {
      return {
        tableData: []
      }
    },
    methods:{
      jump(index){
        this.$router.push(
          {path:"/index3",}
        );
      const store = storeId()
      store.$patch((state) => {
          state.area =  {area:this.tableData[index].orgName,orgId:this.tableData[index].orgId}
          sessionStorage.setItem('area', state.area)
      })
      }
    },
    computed: {
      ...mapState(storeId, ['Business','area']),
    }
  }
</script>
