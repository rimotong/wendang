<template>
<div>
  <el-table
    :data="tableData"
    style="width: 100%;">
    <el-table-column
      label="事业群"
      width="auto">
      <template slot-scope="scope">
        <div @click="jump(scope.$index)">{{scope.row.orgName}}</div>
      </template>
    </el-table-column>
    <el-table-column
      prop="virtualRoomSize"
      label="大小"
      width="180">
    </el-table-column>
    <el-table-column
      prop="updateDate"
      label="更新时间"
      width="180">
    </el-table-column>
  </el-table>
</div>
</template>

<script>
import { mapState,mapActions } from 'pinia'
import {getUserVirtualRoom} from "@/tools/index"
import storeId  from '@/store'
  export default {
    created(){
      if(this.pid==1){
        this.$router.push(
          {path:"/index2",}
        );
      }
      getUserVirtualRoom()
      .then((res)=>{
        this.tableData = res
      })
    },
    data() {
      return {
        tableData: [
        //   {
        //   date: 'CNSBG',
        //   name: '王小虎1',
        //   address: '上海市'
        // }, {
        //   date: 'TSBG',
        //   name: '王小虎2',
        //   address: '普陀区'
        // }, {
        //   date: 'ST',
        //   name: '王小虎3',
        //   address: '金沙江路'
        // }, {
        //   date: 'Fii',
        //   name: '王小虎',
        //   address: '1516 弄'
        // }
        ]
      }
    },
    methods:{
      ...mapActions(storeId, ['updatePhone','pid']),
      jump(index){
        this.$router.push(
          {path:"/index2",}
        );
        const store = storeId()
        store.$patch((state) => {
          state.Business = {Business:this.tableData[index].orgName,orgId:this.tableData[index].orgId}
          sessionStorage.setItem('Business', state.Business)
        })
        // store.updatePhone(this.tableData[index].date)
      }
    },
    computed: {
      ...mapState(storeId, ['Business','pid']),
    }
  }
</script>
