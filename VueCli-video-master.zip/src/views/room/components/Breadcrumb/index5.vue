<template>
  <div>
    <el-container class="container">
      <el-aside width="260px" class="aside">
        <div class="main">
          <el-tabs style="margin-top: 5px;" v-model="activeName">
            <el-tab-pane label="视频" name="first">
              <ul>
                <li v-for="(item,idx) in lists.virtualRoomVideoInfoList" :key="idx" :class="videoIndexs==idx?'lis':''" @click="video(item.viewPath,item.virtualRoomId,item.fileId,idx)" class="li">{{item.fileName}}<label style="float:right;">{{item.time}}</label></li>
              </ul>
            </el-tab-pane>
            <el-tab-pane label="文件" name="second">
              <ul>
                <li v-for="(item,index) in lists.virtualRoomFileInfoList" :key="index" :class="indexs==index?'lis':''" @click="file(item.viewPath,index)" class="li">{{item.fileName}}<label style="float:right;">{{item.time}}</label></li>
              </ul>
            </el-tab-pane>
          </el-tabs>
          <el-upload
            class="button"
            :before-upload="beforeUpload"
            :show-file-list="false"
            :action="UpUrl"
            :accept="fileAccept.join(',')"
            :headers="uploadHeaders"
            :on-success="uploadSuccess"
            :on-error="uploadError"
            :data="{fileType:2,orgId:building.orgId}"
            multiple
            :limit="3"
            :on-exceed="handleExceed"
            >
            <el-button v-if="activeName=='second'" size='mini'  @click="addFileName"><svg-icon icon-class="添加_add" />上传文件</el-button>
          </el-upload>
          <el-upload
            class="button"
            :before-upload="beforeaddVideo"
            :show-file-list="false"
            :action="UpUrl"
            :headers="uploadHeaders"
            :accept="accept.join(',')"
            :on-success="uploadSuccess"
            :on-error="uploadError"
            :data="{fileType:1,orgId:building.orgId}"
            multiple
            :limit="3"
            :on-exceed="handleExceed"
            >
            <el-button v-if="activeName=='first'" size='mini'  @click="addVideo"><svg-icon icon-class="添加_add" />上传视频</el-button>
          </el-upload>
        </div>
      </el-aside>
      <el-container>
        <el-main>
          <VideoPlayer v-if="cutover"></VideoPlayer>
          <!-- <Preview v-if="!cutover" :fileName="fileName"></Preview> -->
          <div style="color: #ffffff" v-if="!cutover" v-html="fileContent"></div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>
<script>
import {baseURLs} from "@/tools/network"
import { mapState,mapActions } from 'pinia'
import storeId  from '@/store'
import axios from 'axios';
import {getUserVirtualRoom} from "@/tools/index"
import Preview from "@/components/preview"
import VideoPlayer from "@/components/flvupload.vue"
export default {
  props: {
      // 最大允许上传个数
      limit: {
          type: Number,
          default: 3,
      },
      // 接受上传的文件类型数组
      accept: {
        type: Array,
        default: () => ['video/mp4','video/flv', ], // 类型限制,
      },
      fileAccept:{
        type: Array,
        default: () => ['application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation','application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf'], // 类型限制,.xls,.xlsx,.ppt,.pptx,.doc,.docx
      },
      // 最大允许文件大小，单位MB
      fileSize: {
          type: Number,
          default: 1000,
      }
  },
  components:{Preview,VideoPlayer},
  created(){
    if(this.Factory.orgId==undefined){
      this.$router.push("/index1")
    }
    this.updates()
  },
  data() {
    return {
      // fileList:null,
      uploadHeaders:{"authToken":"7HJ1lGsb5UER2hQHgU7/Og=="},
      cutover:true,
      // UpUrl:"http://10.139.198.227:8080/api-remoteAudit/virtualRoom/upload", //本地上传接口
      UpUrl:"http://10.125.129.6/ra/virtualRoom/upload",
      activeName: 'first',
      indexs:"",
      videoIndexs:"",
      fileFormData:null,
      fileContent:null,
      videoName:null,
      fileNameList:[],
      fileslists:[],
      list:[],
      lists:[]
    };
},
  computed: {
    ...mapState(storeId, ['Factory','building']),
  },
  methods:{
    ...mapActions(storeId, ['virtualVideoUrl']),
    updates(){
      let fileFormDatas = new FormData();
      fileFormDatas.append("pid",this.building.orgId)
      getUserVirtualRoom(
        fileFormDatas
      )
      .then((res)=>{
        this.lists = res
      })
    },
    video(viewPath,id,fileId,index){
      this.cutover = true
      this.videoIndexs = index
      const store = storeId()
      store.$patch((state) => {
        state.virtualVideoUrl = viewPath
        state.recordId = id
        state.fileId = fileId
      })
      this.fileContent=""
    },
    file(viewPath,index){
      this.cutover = false
      this.indexs = index
      axios.post(viewPath)
        .then(res=>{
          this.fileContent=res.message         
        })
      const store = storeId()
      store.$patch((state) => {
        state.virtualVideoUrl = ""
        state.recordId = ""
        state.fileId = ""
      })
    },
    addVideo(){
    },
    addFileName(){
    },
    handleExceed(files, fileList) {
      this.$message.warning(`当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
    },
    uploadSuccess(response, file, fileList){
      console.log("response",response)
      if(response.code==100){
        this.updates()
        this.$message.success("上传成功")
      }else{
        this.$message.warning("上传失败")
        console.log("fileList",fileList)
      }
    },
    uploadError(response, file, fileList){
      this.$message.warning("上传失败")
    },
    beforeUpload(file){
      // this.url = `?infoId=${res}&connectTableName=purchase_parity_info&connectFieldName=parity_id`;
      const extension2 = file.name.split(".").pop() === "doc";
      const extension3 = file.name.split(".").pop()=== "xls";
      const extension4 = file.name.split(".").pop()=== "xlsx";
      const extension5 = file.name.split(".").pop()=== "docx";
      const extension6 = file.name.split(".").pop()=== "pdf";
      const isLt10M = file.size / 1024 / 1024 < 1000;
      if (
        !extension2 &&
        !extension3 &&
        !extension4 &&
        !extension5 &&
        !extension6
      ) {
        this.$message.warning(
          "上传模板只能是 txt、doc、xls、xlsx、docx、pdf格式!"
        );
        return;
      }
      if (!isLt10M) {
        this.$message.warning("上传模板大小不能超过 1000MB!");
        return;
      }
    }, 
    beforeaddVideo(file){
      console.log('file.szie', file.size)
      console.log('file.type', file.type)
      const isSize = file.size/ 1024 / 1024 // 文件大小
      if (!this.accept.includes(file.type)) {
          this.$message.error('请上传正确的图片格式');
          return false;
      }
      if (this.fileSize && isSize > this.fileSize) {
          this.$message.error(`上传图片大小不能超过${this.fileSize}MB!`);
          return false;
      }
    } 
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-tabs__item {
  color: #ffffff;
}
.el-card__body,::v-deep .el-main {
  padding: 0px;
}
.container{
  margin-top: 20px;
  height: calc(100vh - 260px);
  background: #1c2737;
  .aside{
    height: inherit;
    overflow-y: auto;
    scrollbar-width: thin;
    .main{
      position: relative;
      display: grid;
      .button{
        position: absolute;
        margin-top: 10px;
        right:10px;
        background: rgba(88, 62, 62, 0);
        border: none;
        font-size: 16px;
        color: #409eff;
      }
    }
    .li{
      padding: 5px 10px;  
    }
    .li:hover{
      background: #409eff;
    }
    .lis{
      background: #409eff;
    }
  }
}
</style>