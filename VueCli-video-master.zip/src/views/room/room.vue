<template>
<div class="rooms">
  <div class="room">
    <section class="section">
      <span class="font">虚拟房间</span>
      <!-- <el-input
        v-model="name"
        placeholder="输入名称关键字"
        style="width:400px;margin-left:50px"
      >
        <i slot="prefix" class="el-icon-search" style="line-height: 40px;font-size:150%"></i>
      </el-input>
      <el-button type="primary" style="margin-left:30px">查询</el-button>
      <el-button type="info" style="margin-left:20px">重置</el-button> -->
    </section>
    <el-breadcrumb style="margin-top:30px" separator="/">
      <el-breadcrumb-item :to="{ path: '/index1' }">事业群</el-breadcrumb-item>
      <el-breadcrumb-item v-if="this.$route.meta.breadNumber>1"><span @click="jump('/index2')">{{Business.Business}}</span></el-breadcrumb-item>
      <el-breadcrumb-item v-if="this.$route.meta.breadNumber>2"><span @click="jump('/index3')">{{area.area}}</span></el-breadcrumb-item>
      <el-breadcrumb-item v-if="this.$route.meta.breadNumber>3"><span @click="jump('/index4')">{{Factory.Factory}}</span></el-breadcrumb-item>
      <el-breadcrumb-item v-if="this.$route.meta.breadNumber>4"><span @click="jump('/index5')">{{building.building}}</span></el-breadcrumb-item>
    </el-breadcrumb>
    <router-view></router-view>
  </div>
</div>
</template>
<script>
import { mapState } from 'pinia'
import storeId  from '@/store'
// import {getUserVirtualRoom} from "@/tools/index"
export default {
  data() {
    return {
      // name: '',
      RoomDate:""
    };
  },
  methods:{
    jump(router){
      this.$router.push(
        {path:router}
      );
    },
  },
  computed: {
    ...mapState(storeId, ['Business','area','Factory','building','pid']),
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-breadcrumb__item:last-child .el-breadcrumb__inner,::v-deep .el-breadcrumb__item:last-child .el-breadcrumb__inner a,::v-deep .el-breadcrumb__item:last-child .el-breadcrumb__inner a:hover,::v-deep .el-breadcrumb__item:last-child .el-breadcrumb__inner:hover {
  font-weight: 400;
  color: #ffffff;
  cursor: text;
}
::v-deep .el-breadcrumb__inner {
  color: #ffffff;
}
::v-deep .el-button--info {
  color: #FFF;
  background-color: #90939900;
  border-color: #909399;
}
::v-deep .el-input {
  position: relative;
  font-size: 14px;
  display: inline-block;
  line-height: 80px;
}
::v-deep .el-textarea__inner,::v-deep  .el-input__inner{
        background: transparent;
        color: #fff;
   }
.rooms{
  background-color: rgba(6, 27, 58, 1);
  color: azure;
  .room{
    width: 80%;
    margin: auto;
    height: calc(100vh - 80px);
    overflow-y: auto;
    scrollbar-width: thin;
    color: azure;
    .section{
      margin-top: 20px;
      height: 80px;
      .font{
        line-height: 80px;
        font-size: 26px;
      }
    }
  }
}
::v-deep .el-table,
  ::v-deep .el-table__expanded-cell {
    background-color: transparent !important;
    color: rgb(255, 255, 255);
  }
  /* 表格内背景颜色 */
  ::v-deep .el-table th,
  ::v-deep .el-table tr,
  ::v-deep .el-table td {
    background-color: transparent !important;
    color: rgb(255, 255, 255);
  }
</style>