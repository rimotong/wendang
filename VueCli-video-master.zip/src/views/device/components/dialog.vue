<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    width="826px"
    @close="QualityDialogClose"
      >
    <div class="dialog">
      <el-row :gutter="20">
        <el-form :label-position="labelPosition" label-width="90px" :model="fromdata" class="demo-form-inline">
          <el-col :span="12">
            <el-form-item label="设备名称">
              <el-input v-model="fromdata.equipmentName" placeholder="设备名称"  style="width:280px" ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="视频流地址">
              <el-input v-model="fromdata.videoStreamAddress" placeholder="请输入视频流地址" style="width:280px" ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="相机归属">
              <el-select v-model="cameraBelongTo" placeholder="请选择相机归属">
                <el-option
                  v-for="item in onno"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="接口地址">
              <el-input v-model="fromdata.apiAddress" placeholder="请输入接口地址"  style="width:280px" ></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="24">
            <el-form-item label="事业群">
              <el-select v-model="fromdata.bgName" placeholder="请选择">
                <el-option
                  v-for="item in options"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId"
                  @click.native="bgMediaId(item.orgId,item.orgName)">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="区域">
              <el-select v-model="fromdata.regionName" placeholder="请选择">
                <el-option
                  v-for="item in regionList"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId"
                  @click.native="regionMediaId(item.orgId,item.orgName)">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="园区">
              <el-select v-model="fromdata.areaName" placeholder="请选择">
                <el-option
                  v-for="item in optionsArea"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId"
                  @click.native="areaMediaId(item.orgId,item.orgName)">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="楼栋">
              <el-select v-model="fromdata.buildName" placeholder="请选择">
                <el-option
                  v-for="item in optionsBuild"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId"
                  @click.native="buildMediaId(item.orgId,item.orgName)">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="楼层">
              <el-select v-model="fromdata.floorName" @change="userDistricts" placeholder="请选择">
                <el-option
                  v-for="item in optionsfloor"
                  :key="item.orgId"
                  :label="item.orgName"
                  :value="item.orgId"
                  @click.native="floorMediaId(item.orgId,item.orgName)">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-form>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="Sure">确 定</el-button>
        <el-button @click="QualityDialogClose">取 消</el-button>
      </span>
    </div>
  </el-dialog>
</template>
<script>
import {getEquipmentInfoList,getDropDownOptions,uploadTemplate,saveOrUpdate,deleteAuditEquipment} from "@/tools/index"
export default {
  props:{
    dialogVisible:{
      type:Boolean,
      default:false
    },
    fromdata:{
      type:Object,
      default(){
        return {
        }
      }
    },
    state:{
      type:String,
      default:"add"
    }
  },
  // mounted(){
  // },
  watch:{
    dialogVisible(){
      getDropDownOptions().then(res=>{
        this.options = res
      })
      if(this.fromdata.bgId){
        getDropDownOptions({orgId:this.fromdata.bgId}).then(res=>{
          this.regionList = res
        })
      }
      if(this.fromdata.regionId){
        getDropDownOptions({orgId:this.fromdata.regionId}).then(res=>{
          this.optionsArea = res
        })
      }
      if(this.fromdata.areaId){
        getDropDownOptions({orgId:this.fromdata.areaId}).then(res=>{
          this.optionsBuild = res
        })
      }
      if(this.fromdata.buildId){
        getDropDownOptions({orgId:this.fromdata.buildId}).then(res=>{
          this.optionsfloor = res
        })
      }
      this.Visible = this.dialogVisible
    },
    state(){
      if(this.state=="add"){
        this.title = "新建相机"
        this.fromdata={"business":"","name":"","address":"","Park":"","building":"","floor":"","area":"","bgName":"","bgId":"","regionId":"","regionName":"","areaId":"","areaName":"","buildId":"","buildName":"","floorId":"","floorName":""}
        this.regionList = [],this.optionsArea= [], this.optionsBuild= [], this.optionsfloor=[]
      }else{
        this.title = "编辑相机"
      }
    } 
  },
  data() {
    return {
      bgId:"",
      title:"",
      regionId:"",
      areaId:"",
      buildId:"",
      floorId:"",
      onno:"",
      cameraBelongTo:"",
      regionList:[],
      optionsArea:[],
      optionsBuild:[],
      optionsfloor:[],
      labelPosition: 'right',//右对齐
      value: '',
      options: [],
      Visible:false
    }
  },
  methods: {
    bgMediaId(id,name){this.bgId = id,this.fromdata.bgId = id,this.fromdata.bgName = name
      this.regionId = "",this.fromdata.regionId = "",this.fromdata.regionName = "",this.regionList = []
      this.areaId = "",this.fromdata.areaId = "",this.fromdata.areaName = "",this.optionsArea = []
      this.buildId = "",this.fromdata.buildId = "",this.fromdata.buildName = "",this.optionsBuild = []
      this.floorId = "",this.fromdata.floorId = "",this.fromdata.floorName = "",this.optionsfloor = []
      getDropDownOptions({orgId:this.bgId}).then(res=>{
        this.regionList  = res
      })
    },
    regionMediaId(id,name){this.regionId = id,this.fromdata.regionId = id,this.fromdata.regionName = name
      this.areaId = "",this.fromdata.areaId = "",this.fromdata.areaName = "",this.optionsArea = []
      this.buildId = "",this.fromdata.buildId = "",this.fromdata.buildName = "",this.optionsBuild = []
      this.floorId = "",this.fromdata.floorId = "",this.fromdata.floorName = "",this.optionsfloor = []
      getDropDownOptions({orgId:this.regionId}).then(res=>{
        this.optionsArea  = res
      })
    },
    areaMediaId(id,name){this.areaId = id,this.fromdata.areaId = id,this.fromdata.areaName = name
      this.buildId = "",this.fromdata.buildId = "",this.fromdata.buildName = "",this.optionsBuild = []
      this.floorId = "",this.fromdata.floorId = "",this.fromdata.floorName = "",this.optionsfloor = []
      getDropDownOptions({orgId:this.areaId}).then(res=>{
        this.optionsBuild  = res
      })   
    },
    buildMediaId(id,name){this.buildId = id,this.fromdata.buildId = id,this.fromdata.buildName = name
      this.floorId = "",this.fromdata.floorId = "",this.fromdata.floorName = "",this.optionsfloor = []
      getDropDownOptions({orgId:this.buildId}).then(res=>{
        this.optionsfloor  = res
      })   
    },
    floorMediaId(id,name){this.floorId = id,this.fromdata.floorId = id,this.fromdata.floorName = name},
    userDistricts (e) {
      this.$forceUpdate()
    },
    QualityDialogClose() {
      this.$emit("update:dialogVisible", false);
    },
    Sure(){
      this.$emit("Sure",this.fromdata,this.state,this.id);
      this.$emit("update:dialogVisible", false);
    }
  },
}
</script>
<style lang="scss" scoped>
.dialog{
  width: 95%;
  margin: auto;
  color: #FFF;
  .dialog-footer{
    text-align:center;
    display:block;
  }
}
.dialog ::v-deep .el-select .el-input {
  width: 280px;
}
</style>