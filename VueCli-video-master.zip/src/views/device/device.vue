<template>
  <div class="devic">
    <div class="layout">
      <section class="section">
        <div class="font">设备管理</div>
        <section class="child">
          <div>
            <p>设备名称</p>
            <el-input
              v-model="search.equipmentName"
              placeholder="输入名称关键字"
              style="width:200px;"
            >
            </el-input>
          </div>
          <div>
            <p>视频流地址</p>
            <el-input
              v-model="search.videoStreamAddress"
              placeholder="输入名称关键字"
              style="width:200px;"
            >
            </el-input>
          </div>
          <div>
            <p>事业群</p>
            <el-select v-model="value" placeholder="请选择" value-key="label">
              <el-option
                v-for="item in options"
                :key="item.orgId"
                :label="item.orgName"
                :value="item.orgId"
                @click.native="selectMediaId(item.orgName,item.orgId)">
              </el-option>
            </el-select>
          </div>
          <div>
            <p>区域</p>
            <el-select v-model="area" placeholder="请选择">
              <el-option
                v-for="item in  optionsPark"
                :key="item.orgId"
                :label="item.orgName"
                :value="item.orgId"
                @click.native="selectParkId(item.orgName,item.orgId)">
              </el-option>
            </el-select>
          </div>
          <div>
            <p>园区</p>
            <el-select v-model="Park" placeholder="请选择" @change="selectAreaId">
              <el-option
                v-for="item in optionsChild"
                :key="item.orgId"
                :label="item.orgName"
                :value="item.orgId"
                @click.native="selectAreaId(item.orgName,item.orgId)">
              </el-option>
            </el-select>
          </div>
        </section>
        <div>
          <el-button type="primary" style="margin-top:15px" @click="Inquire">查询</el-button>
          <el-button type="info" style="margin-left:20px" @click="reset">重置</el-button>  
        </div>      
      </section>

      <Dialog :dialogVisible.sync="dialogVisible" :fromdata="fromdata" :state="state" @Sure="Sure"></Dialog>
      <div class="table">
        <div class="main">
          <section>
            <span style="font-size: 16px;font-family: 'Roboto Bold', 'Roboto', sans-serif;font-weight: 700;font-style: normal;">风险点统计</span>
            <el-button type="primary" size="small" style="margin-left:20px;margin-top:50px" @click="add"><svg-icon icon-class="add-one" />新增</el-button>
            <!-- <el-button type="primary" size="small" style="margin-left:20px"><svg-icon icon-class="upload" />导入</el-button>  
            <span style="margin-left:20px" @click="dwonLoud">下载导入模板</span> -->
            <el-button type="primary" size="small" style="margin-left:20px;margin-top:50px" @click="videoInfo">视频流地址显示</el-button>
          </section>

          <div style="margin-top:5px;padding:0; width:100%;height:3px;background-color:#737a85;">
            <div style="margin:0;padding:0; width:80px;height:3px;background-color:#409eff;"></div>
          </div>  
          <template>
            <el-table
              :key="randomNum"
              :data="tableData"
              :header-cell-style="{'text-align':'center'}"
              :cell-style="{'text-align':'center'}"
              style="width: 100%;margin-top: 30px;overflow: auto;height:calc(100%-100px);scrollbar-width: thin;">
              <el-table-column type="index" label="序号" width="50px">
              </el-table-column>
              <el-table-column prop="equipmentName" label="设备名称" width="auto">
              </el-table-column>
              <el-table-column label="视频流地址" v-if="info" width="auto">
                <template slot-scope="scope">
                  <span style="color:#409eff;">{{scope.row.videoStreamAddress}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="bgName" label="事业群" width="150">
              </el-table-column>
              <el-table-column prop="areaName" label="园区" width="150">
              </el-table-column>
              <el-table-column prop="buildName" label="楼栋" width="150">
              </el-table-column>
              <el-table-column prop="floorName" label="楼层" width="150">
              </el-table-column>
              <el-table-column label="操作" width="200">
                <template slot-scope="scope">
                  <span style="color:#409eff;padding:0 20px;" @click="edit(scope.$index)">编辑</span>
                  <span style="color:#f56c6c;padding:0 20px;" @click="deleteInfo(scope.row.equipmentId)">删除</span>
                </template>
              </el-table-column>
            </el-table>
            <div class="pagination">
              <el-pagination         
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="[5,10]"
                :page-size="pageSize"
                layout="total, prev, pager, next, jumper"
                :total="totalSize">
              </el-pagination>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios';
import Dialog from "./components/dialog.vue"
import {getEquipmentInfoList,getDropDownOptions,uploadTemplate,saveOrUpdate,deleteAuditEquipment} from "@/tools/index"
export default {
  components:{Dialog},
  data() {
    return {
      search:{
        videoStreamAddress:"",
        equipmentName:"",
      },
      info:false,
      randomNum:null,
      fromdata:{},
      state:null,
      tableDataIndex:null,
      dialogVisible:false,
      pageSize:5,
      totalSize:null,
      currentPage:1,//当前页数
      name: 'value',
      options: [],
      optionsChild:[],
      optionsPark:[],
      area:'',
      areaId:'',
      Park:'',
      ParkId:'',
      value: '',
      valueId:'',
      tableData: []
    };
  },
  created(){
    this.onSubmit()
    getDropDownOptions().then(res=>{
      this.options = res
    })
  },
  methods:{
    videoInfo(){
      this.info = !this.info
    },
    deleteInfo(id){ //arrayFormat: 'indices'
      deleteAuditEquipment({equipmentIds:[id]}).then(res=>{
        this.onSubmit()
        this.$message.success("删除成功")
      }).catch(err=>{
        this.$message.error("删除失败");
      })
    },
    reset(){
      this.search={
        videoStreamAddress:"",
        equipmentName:"",
      }
      this.area='',
      this.areaId='',
      this.Park='',
      this.ParkId='',
      this.value='',
      this.valueId=''
    },
    add(){
      this.dialogVisible = true
      this.state = "add"
      this.fromdata = {
        business: '',
        name: '',
        address: '',
        Park:"",
        building:"",
        floor:"",
        area:""
      }
    },
    dwonLoud(){
      axios({
        method: 'get',
        url: 'http://10.139.199.16/mis/api-remoteAudit/equipment/downloadTemplate',
        responseType: 'arraybuffer',
      }).then(res=>{
        console.log("222",res)
        let blob = new Blob([res], { type: "application/vnd.ms-excel" });
        if (window.navigator.msSaveOrOpenBlob) {
          //兼容 IE & EDGE
          navigator.msSaveBlob(blob, fileName);
        } else {
          var link = document.createElement("a");
          // 兼容不同浏览器的URL对象
          const url = window.URL || window.webkitURL || window.moxURL;
          // 创建下载链接
          link.href = url.createObjectURL(blob);
          //命名下载名称
          link.download = "设备上传模板.xlsx";
          console.log(link, "link");
          //点击触发下载
          link.click();
          //下载完成进行释放
          url.revokeObjectURL(link.href);
        }
      })
    },
    selectMediaId(name,id){
      this.value = name
      this.valueId = id
      this.areaId = ""
      this.ParkId = ""
      this.area = ""
      this.Park = ""
      getDropDownOptions({orgId:this.valueId}).then(res=>{
        this.optionsPark = res
      })
    },
    selectParkId(name,id){
      this.area = name
      this.areaId = id
      this.Park = ""
      this.ParkId = ""
      getDropDownOptions({orgId:this.areaId}).then(res=>{
        this.optionsChild = res
      })
    },
    selectAreaId(name,id){
      this.Park = name
      this.ParkId = id
    },
    Inquire(){
      getEquipmentInfoList({
        page: this.currentPage,
        limit: this.pageSize,
        data: {
          equipmentName: this.search.equipmentName,
          videoStreamAddress: this.search.videoStreamAddress,
          bgId: this.valueId,
          regionId:this.ParkId,
          areaId: this.areaId
        }
      }).then(res=>{
        this.tableData = res.content
        this.totalSize= res.totalSize
      })
    },
    Sure(dates,fettle,id){
      if(fettle == "add"){
        saveOrUpdate({
          equipmentName:dates.equipmentName,//------------------------------设备名称
          videoStreamAddress:dates.videoStreamAddress ,//--------------设备地址
          cameraBelongTo:dates.cameraBelongTo,//----------------------------------相机归属
          apiAddress:dates.apiAddress,//--------------------------------------接口地址
          bgId:dates.bgId,//----------------------------------------------------事业群（组织id）
          regionId:dates.regionId,//------------------------------------------------区域（组织id）
          areaId:dates.areaId,//-------------------------------------------------园区（组织id）
          buildId:dates.buildId,//------------------------------------------------楼栋（组织id）
          floorId:dates.floorId//-------------------------------------------------楼层（组织id）
        }).then(res=>{
          this.randomNum = Math.random()
          this.onSubmit()
        })
      }else{
        saveOrUpdate({
          equipmentId:dates.equipmentId,
          equipmentName:dates.equipmentName,//------------------------------设备名称
          videoStreamAddress:dates.videoStreamAddress ,//--------------设备地址
          cameraBelongTo:dates.cameraBelongTo,//----------------------------------相机归属
          apiAddress:dates.apiAddress,//--------------------------------------接口地址
          bgId:dates.bgId,//----------------------------------------------------事业群（组织id）
          regionId:dates.regionId,//------------------------------------------------区域（组织id）
          areaId:dates.areaId,//-------------------------------------------------园区（组织id）
          buildId:dates.buildId,//------------------------------------------------楼栋（组织id）
          floorId:dates.floorId//-------------------------------------------------楼层（组织id）
        }).then(res=>{
          this.randomNum = Math.random()
          this.onSubmit()
        })
      }
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.Inquire()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.Inquire()
    },
    onSubmit(){
      getEquipmentInfoList({
        page: this.currentPage,
        limit: this.pageSize,
        data: {
        }
      }).then(res=>{
        this.tableData = res.content
        this.totalSize= res.totalSize
      })
    },
    edit(index){
      this.fromdata = JSON.parse(JSON.stringify(this.tableData[index]))
      this.state = "edit"
      this.tableDataIndex = index
      this.dialogVisible = true
    }
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-form-item__label {
  color: #ffffff;
}
::v-deep .el-dialog__title {
  line-height: 24px;
  font-size: 18px;
  color: #ffffff;
}
::v-deep .el-dialog__body {
  color: #ffffff;
  font-size: 14px;
  word-break: break-all;
}
::v-deep .el-dialog {
  position: relative;
  margin: 0px auto 50px;
  background: rgba(15, 39, 76, 1);
  color: #FFF;
  border-radius: 10px;
  box-shadow: 0 1px 3px rgba(0,0,0,.3);
  box-sizing: border-box;
}
::v-deep .el-pagination button {
  color: #C0C4CC;
  background-color: #FFF0;
  cursor: not-allowed;
}
::v-deep .el-pagination .btn-next, .el-pagination .btn-prev {
  background: center center no-repeat #FFF0;
  background-size: 16px;
  cursor: pointer;
  margin: 0;
  color: #C0C4CC;
}
::v-deep .el-button--info {
  color: #FFF;
  background-color: #90939900;
  border-color: #909399;
}
::v-deep .el-table,::v-deep .el-table tr,::v-deep .el-table td,::v-deep .el-table th {
    background-color: transparent!important;
    color: #fff;
}
// .el-table td.el-table__cell, .el-table th.el-table__cell.is-leaf {
//   border-bottom: 1px solid #EBEEF5;
// } //
::v-deep .el-input {
  position: relative;
  font-size: 14px;
  display: inline-block;
}
::v-deep .el-textarea__inner,::v-deep  .el-input__inner{
        background: transparent;
        color: #fff;
   }
::-webkit-scrollbar {
  width: 0 !important;height: 0;
} //隐藏谷歌浏览器滚动条
.pagination{
	justify-self: center;
	align-self: center;
  margin-top: 20px;
}
.devic{
  background-color: rgba(6, 27, 58, 1);
  color: azure;
  height: calc(100vh - 80px);
  overflow-y: auto;
  scrollbar-width: thin;//火狐浏览器滚动条
  .layout{
    width: 80%;
    margin: auto;
    .section{
      margin-top: 10px;
      height: 60px;
      .child{
        display: flex;
        div{
          padding-right: 20px;
        }
      }
      .font{
        line-height: 80px;
        font-size: 26px;
      }
    }
      .table{
        margin-top: 170px;
        height: 600px;
        margin-bottom: 30px;
        background: #1b2636;
        border-radius: 15px 15px 15px 15px;
        .main{
          width: 90%;
          margin: auto;
          display: grid;
        }
      }
  }
}
</style>