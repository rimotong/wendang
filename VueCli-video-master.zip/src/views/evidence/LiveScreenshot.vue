<template>
  <div class="live" oncontextmenu="self.event.returnValue=false">
    <div class="index" ref="shuxingBox" >
      <div class="top">
        <!-- :body-style="{ padding: '0px',position: relative }" -->
        <span>直播截屏</span>
        <el-button type="primary" v-show="status" @click="toggle">批量导出</el-button>
        <el-button type="primary" v-show="!status" @click="BatchDownload">下载文件</el-button>
        <el-input
          v-model="floor"
          placeholder="输入关键字"
          style="width: 300px;float: right;"
          @change="search(floor)"
        >
          <i slot="prefix" class="el-icon-search" style="font-size:150%;vertical-align: middle;"></i>
        </el-input>
      </div>
      <div v-for="(val, key, idx) in imgList" :key="idx">
        <el-row :gutter="20"> 
          <div @click="selectAll(key,idx)">
            <el-checkbox v-model="dateCheckbox[idx]" disabled class="checkbox" v-show="!status"></el-checkbox>
            <el-button type="primary">{{key}}</el-button></div>
          <div>
            <el-col :span="4" v-for="(item, index) in val" :key="index" v-viewer.static>
              <el-card  class="img">
                <el-checkbox v-model="item.upload" class="checkbox" v-show="!status"></el-checkbox>
                <!-- <viewer  ref="viewer" @inited="inited" :images="item.viewPath.split('')">             -->
                  <img :src="item.viewPath" :id="index" class="image">
                <!-- // </viewer> -->
              </el-card>
              <p>{{item.photoName}}-{{item.photoTime}}</p>
            </el-col>
          </div>
        </el-row>
      </div>
    </div>
  </div>
</template>
<script>
import {getScreenshot} from "@/tools/index"
import JSZip from 'jszip'
import FileSaver from 'file-saver'
export default {
  data() {
    return {
      dateCheckbox:[],
      floor:"",
      status:true,
      imgDataUrl:[],
      upload: false,
      imgList:[]
    };
  },
  watch:{
    dateCheckbox: {
      handler(val) {
        this.dateCheckbox=val
      },
      deep: true, // 深度监听
    }
  },
  created(){
    getScreenshot({
      pageRequest:{
        order: "",
        pageIndex: 1,
        pageSize: 5,
        prop: ""
      },
      photoName: "",
      photoType: 1
    }).then(res=>{
      this.imgList = res
    })
  },
  methods:{
    inited (viewer) {
      this.$viewer = viewer
    },
    search(text){
      getScreenshot({
        pageRequest:{
          order: "",
          pageIndex: 1,
          pageSize: 5,
          prop: ""
        },
        photoName:text,
        photoType: 1
      }).then(res=>{
        this.imgList = res
      })
    },
    selectAll(key,index){
      this.dateCheckbox[index]=!this.dateCheckbox[index]
      console.log(this.dateCheckbox[index])
      if(this.dateCheckbox[index]){
        this.imgList[key].forEach((item,index) =>{
          item.upload = true
        })
      }else{
        this.imgList[key].forEach((item,index) =>{
          item.upload = false
        })
      }
    },
    toggle(){
      this.status = !this.status
    },
    getImgArrayBuffer(url){
      let _this=this;
      return new Promise((resolve, reject) => {
          //通过请求获取文件blob格式
        let xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", url, true);
        xmlhttp.responseType = "blob";
        xmlhttp.onload = function () {
          if (this.status == 200) {
            resolve(this.response);
          }else{
            reject(this.status);
          }
        }
        xmlhttp.send();
      });
    },
  // imgDataUrl 数据的url数组
  BatchDownload(){
    this.status = !this.status
    Object.keys(this.imgList).forEach((e,index) =>{
      this.imgList[e].forEach((item)=>{
        if(item.upload){
          this.imgDataUrl.push(item)
        }
      })
    })
    // this.imgList.forEach((item)=>{
    //   console.log("item",item)
    //   // if(item.upload){
    //   //   this.imgDataUrl.push(item)
    //   // }
    // })
    let _this = this;
    let zip = new JSZip();
    let cache = {};
    let promises = [];
    _this.title = '正在加载压缩文件';
    if(this.imgDataUrl.length>0){
      for (let item of this.imgDataUrl) {
        const promise= _this.getImgArrayBuffer(item.viewPath).then(data => {
          // 下载文件, 并存成ArrayBuffer对象(blob)
          zip.file(item.photoName+item.photoTime+".png", data, { binary: true }); // 逐个添加文件
          cache[item.photoName+".png"] = data;
        });
        promises.push(promise);
      }
      Promise.all(promises).then(() => {
        zip.generateAsync({ type: "blob" }).then(content => {
          _this.title = '正在压缩';
          // 生成二进制流
          FileSaver.saveAs(content, '数据包.zip'); // 利用file-saver保存文件  自定义文件名
          _this.title = '压缩完成';
        });
      }).catch(res=>{
        _this.$message.error('文件压缩失败');
      });
    }else{
      this.$message.error("您还未选择图片！")
    }
    this.imgDataUrl = []
  },
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-textarea__inner,::v-deep  .el-input__inner{
  background: transparent;
  color: #fff;
}
::v-deep .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner {
  background-color: #3586FFA6;
  border-color: #DCDFE638;
}
::v-deep .el-card {
  border-radius: 4px;
  border: 1px solid #ebeef500;
  background-color: rgba(255, 255, 255, 0);
}
.live{
  background-color: rgba(6, 27, 58, 1);
  color: azure;
  height: calc(100vh - 80px);
  overflow-y: auto;
  scrollbar-width: thin;//火狐浏览器滚动条
  .index{
    width: 90%;
    margin: auto;
    .top{
      line-height: 100px;
      span{
        font-size: 20px;
        font-weight: 700;
        padding-right: 50px;
      }
    }
    .img{
      height: 150px;
      .image{
        object-fit:contain;
        width: 100%;
        height: 100%
      }
    }
  }
}
.checkbox{
  position:absolute;
}
</style>