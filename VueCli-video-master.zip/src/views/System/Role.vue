<template>
  <div class="demand">
    <ul class="lfnav">
      <div class="manage">角色管理<span @click="add"><svg-icon icon-class="add" class="svg" /></span></div>
      <li       
        v-for="(item,index) in roles" :key="index"
        @click="fromData(index,item)"
        :class="indexs==index?'lis':''"
      >
        {{item.roleDescribe}}
        <span @click="delet(item.roleId)">
          <svg-icon icon-class="delete-three" class="svg" />
        </span>
      </li>
      <el-dialog
        title="确认删除"
        :visible.sync="dialogVisible"
        width="30%"
        :before-close="handleClose">
        <span>确认删除该角色后，原有属于该角色的用户将失去角色权限，请确认是否删除该角色？</span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="deleton">确 定</el-button>
        </span>
      </el-dialog>
      <li v-show="adds"><input v-model="insertName" placeholder="请输入" @change="insert"></li>
    </ul>
    <router-view :tableData="RoleData"></router-view>
  </div>
</template>
<script>
import {getRolePermission,deleteRole,insertRole} from "@/tools/index"
export default {
  components: {},
  data() {
    return {
      adds:false,
      indexs:"",
      id:"",
      insertName:"",
      roles:[
      ],
      dialogVisible: false,
      RoleData:null
    };
  },
  watch: {
  },
  created(){
    this.reload()
  },
  methods: {
    deleton(){
      deleteRole(this.id).then(res=>{
        this.id = ""
        this.dialogVisible=false
        this.reload()
      })
    },
    reload(){
      getRolePermission().then(res=>{
        this.roles = res
        this.RoleData = this.roles[0].userOrgRoleVos
      })
    },
    insert(){
      insertRole({
        roleDescribe:this.insertName
        }).then(res=>{
          this.adds = false
      })
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    fromData(index,item){
      this.RoleData = this.roles[index].userOrgRoleVos
      this.indexs = index
    },
    add(){
      this.adds = true
    },
    delet(id){
      this.id = id
      this.dialogVisible=true
    }
  },
};
</script>
<style lang="scss" scoped>
.demand {
  color: #ffffff;
  height: calc(100vh - 80px) !important;
  display: flex;
  .lfnav {
    list-style: none;
    width: 300px;
    height:100%;
    // background-color:rgb(8, 31, 65);
    background-color:rgba(28, 39, 55, 1);
    overflow:visible;
    .manage{
      height: 60px;
      line-height: 60px;
      font-size: 25px;
      padding-left: 10px;
      .svg{
        float: right;
        height: 60px;
        font-size: 25px;
        line-height: 60px;
        padding-right: 10px;
      }
    }
    li {
      // padding-left: 16px;
      cursor: pointer;
      height: 57px;
      font-size: 20px;
      line-height: 57px;
      padding-left: 10px;
      .svg{
        float: right;
        height: 57px;
        font-size: 25px;
        line-height: 57px;
        padding-right: 10px;
      }
    }
    li:hover{
        background: #0d3774;
    }
    .lis{
      background: #0d3774;
    }
  }
  .lfnav_color {
    background-color: rgb(1, 46, 114);
    color: #ffffff;
  }
}
::v-deep .el-submenu__title{
    border-bottom: 1px solid #000;
}
::v-deep .el-submenu.is-active .el-submenu__title {
  border-bottom-color: #ffffff;
}
::v-deep .el-submenu__title:focus{
  outline: 0 !important;  
  color: #ffffff !important;  
  background: none !important;  
  border-bottom: 1px solid #000;
}
::v-deep  .el-submenu__title:hover{  
  outline: 0 !important;  
  color: #ffffff !important;  
  background: none !important;  
  border-bottom: 1px solid #000;
}  
::v-deep .el-menu-item:hover{  
  outline: 0 !important;  
  color: #ffffff !important;  
}  
::v-deep .el-menu-item{
    border-bottom: 1px solid #000;  
    background: none !important;  
}

::v-deep .is-active {  
  color: rgb(255, 255, 255) !important;  
  background: none !important;
}  
</style>
