<template>
  <div class="list-detail">
    <el-menu
      default-active="1"
      class="el-menu-vertical"
      background-color="rgba(28, 39, 55, 1)"
      text-color="#fff"
      active-text-color="#FF660A"
    >
      <CustomElMenu :list="tableData" class="list"></CustomElMenu>
    </el-menu>
  </div>
</template>
<script>
import CustomElMenu from "./data.vue";
export default {
  name: "Parent",
  props:{
    tableData:{
      type:Array,
      default(){
        return []
      }
    }
  },
  mounted(){
    console.log(this.tableData)
  },
  components: { CustomElMenu },
  data() {
    return {
    menuList: [
    {
      id: 2,
      name: "课程大纲",
      children: [
      {
        id: 21,
        name: "子1",
        children: [
        {
          id: 31,
          name: "子2",
          children: [{
            id: 41,
            monitor:[{name:"00",ip:"11.22.33"},{name:"01",ip:"11.22.33"},{name:"02",ip:"11.22.33"},]
          }]
        },
        {
          id: 32,
          name: "子3",
          children: [{
            id: 42,
            monitor:[{name:"00",ip:"11.22.33"},{name:"01",ip:"11.22.33"},{name:"02",ip:"11.22.33"},]
          }]
        },
        ],
      },
      ],
    },
    {
      id: 3,
      name: "课程管理",
    },
    {
      id: 4,
      name: "课程管理",
    },
      ],
    }
  }
}
</script>
<style lang="scss" scoped>
.list-detail{
  padding-left: 50px;
  padding-top: 50px;
  overflow-y: auto;
  width: 100%;
  // background-color: rgba(28, 39, 55, 1);
  background-color: rgba(6, 27, 58, 1);
  color: #ffffff;
  .list{
    height: 100%;
    width: 100%;
  }
} 
::v-deep .el-menu-vertical{
  width: 100%;
}
::v-deep .el-menu-item ::v-deep.is-active {  
  color: #fff !important;  
  background: #409EFF !important;  
}  
</style>
