<template>
  <div>
    <span @click="tu">user</span>
    <div class="level-one" v-show="obj.level == 1" v-for="(obj,index) in bar1" :key="index"><a>{{obj.title}}</a> 
      <div class="level-two" v-show="obj1.parentId == obj.id " v-for="(obj1,index1) in bar1" :key="index1"><a>{{obj1.title}}</a> 
        <div class="level-three" v-show="obj2.parentId == obj1.id" v-for="(obj2,index2) in bar1" :key="index2"><a>{{obj2.title}}</a></div> 
      </div> 
    </div> 
  </div>
</template>
<script>
export default {
  props:{
    tableData:{
      type:Array,
      default(){ return "" }
    }
  },
  data() {
    return {
      bar1:[ 
      /*所有第一级菜单*/
      { 
        title:'一级菜单（1）', 
        id:1,       //选项的唯一ID 
        parentId:0,    //父级的ID 
        level:1      //所处的层级 
      }, 
      { 
        title:'一级菜单（2）', 
        id:2, 
        parentId:0, 
        level:1 
      }, 
      { 
        title:'一级菜单（3）', 
        id:3, 
        parentId:0, 
        level:1, 
      }, 
      /*所有二级菜单*/
      { 
        title:'二级菜单（1.1）', 
        id:4, 
        parentId:1, 
        level:2 
      }, 
      { 
        title:'二级菜单（1.2）', 
        id:5, 
        parentId:1, 
        level:2 
      }, 
      { 
        title:'二级菜单（2.1）', 
        id:6, 
        parentId:2, 
        level:2 
      }, 
      { 
        title:'二级菜单（2.2）', 
        id:7, 
        parentId:2, 
        level:2 
      }, 
      /*所有三级菜单*/
      { 
        title:'三级菜单（1.1.1）', 
        id:8, 
        parentId:4, 
        level:3 
      }, 
      { 
        title:'三级菜单（1.1.2）', 
        id:9, 
        parentId:4, 
        level:3 
      } 
      ]
    };
  },
  methods:{
    tu(){
      console.log("tableData",this.tableData[0].name)
    }
  }
}
</script>
<style lang="scss" scoped>
  span{
    color: aqua;
  }
  .level-one{ 
  text-indent: 1em; 
  } 
  .level-two{ 
  text-indent: 2em; 
  } 
  .level-three{ 
  text-indent: 3em; 
  } 
</style>