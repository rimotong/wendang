<template>
  <div>
    <div class="list-item" v-for="(item, index) in list" :key="index">
      <div class="item-name">
        <span>{{item.name}}</span>
      </div>
      <div v-if="item.monitor">
        <span>{{item.monitor.name}}</span>
        <span>{{item.monitor.ip}}</span>
      </div>
      <div v-if="item.children" class="children-item">
        <list :list="item.children"></list>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "List",
  props: {
    list: Array
  }
};
      list: [{
        name: "经济",
        level:1,
        children: [{
          name: "如家",
          level:2,
          children: [{
            name: "上江路-如家",
            level:3,
            children:[{
              level:4,
              monitor:{
                name:"111",
                ip:"11.22.33"
              }
            }]
          },
          {
            name: "望江路-如家",
            level:3,
            }]
        },
        {
          name: "7天",
          level:2,
          children: [{
            name: "长江路-7天",
            level:3,
          },
          {
            name: "望江路-7天",
            level:3,
            }]
          }]
        }]
</script>