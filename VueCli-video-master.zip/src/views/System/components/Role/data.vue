<template>
  <div>
    <component
      :is="(menuItem.userOrgRoleVos ? 'el-submenu' : 'el-menu-item')"
      v-for="menuItem in list"
      :key="menuItem.orgId"
      class="border"
      :index="menuItem.orgId.toString()"
      :class="{'active':menuItem.monitor}"
    >
      <template v-if="menuItem.userOrgRoleVos">
        <template slot="title"><el-checkbox v-model="menuItem.choose" style="margin-top:-5px" />{{ menuItem.orgName }}</template>
        <customElMenu :list="menuItem.userOrgRoleVos"></customElMenu>
      </template>
      <template v-else>
        <span v-if="menuItem.orgName" slot="title"><el-checkbox v-model="menuItem.choose" style="margin-top:-5px" />{{ menuItem.orgName }}</span>
        <!-- <ul v-else>
            <li class="flot" v-for="(item,idx) in menuItem.monitor" :key="idx">
                <el-card class="box-card">
                    <div class="item">{{item.name}}</div>
                    <div class="item">{{item.ip}}</div>
                </el-card>
            </li>
        </ul> -->
      </template>
    </component>
  </div>
</template>

<script>
export default {
  name: "customElMenu",
  props: {
    list: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {};
  },
  methods: {
      cls(val){
          if(val){

          }
      }
  },
};
</script>

<style lang="scss">
.flot{
    float: left;
    width: 50%;
}
.active{
  display: table;
  height: 100%;
  width: 100%;
}
</style>