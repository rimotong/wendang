<template>
<div class="rooms">
  <div class="room">
    <section class="section">
      <span class="font">区域管理</span>
      <!-- <el-input
        v-model="name"
        placeholder="输入名称关键字"
        style="width:400px;margin-left:50px"
      >
        <i slot="prefix" class="el-icon-search" style="line-height: 40px;font-size:150%"></i>
      </el-input>
      <el-button type="primary" style="margin-left:30px">查询</el-button>
      <el-button type="info" style="margin-left:20px">重置</el-button> -->
      <el-button type="primary" style="margin-left:30px" @click="addstate=true">新增</el-button>
    </section>
    <div class="info">
      <el-row :gutter="20">
        <el-col :span="6" v-for="(item,index) in list" :key="index">
          <div class="box-card">
            <div class="header">
              <span>{{item.orgName}}</span>
              <el-dropdown trigger="click" style="float: right;">
                <!-- <button type="text" class="icon" v-show="item.del">
                  <i class="el-icon-more"></i>
                </button> -->
                <label style="float: right;" v-show="item.del">
                  <span @click="edit(index)"><svg-icon icon-class="编辑_editor" /></span>
                  <span @click="dialog(item.orgId)"><svg-icon icon-class="删除_delete" /></span>
                </label>
                <label style="float: right;" v-show="!item.del">
                  <label style="float: right;" @click="addListInfo(`1`,index)">
                    <svg-icon icon-class="添加_add" />
                  </label>
                  <span @click="confirm(index)"><i class="el-icon-circle-check" style="color: #aedd80;"></i></span>
                </label>
                <!-- <el-dropdown-menu slot="dropdown">
                  <div @click="edit(index)"><el-dropdown-item>编辑</el-dropdown-item></div>
                  <div @click="strike()"><el-dropdown-item style="color: red;">删除</el-dropdown-item></div>
                </el-dropdown-menu> -->
              </el-dropdown>
              <div style="margin-top: 5px;">设备数：{{item.equipmentNumber}}</div>
            </div>
            <div class="dropdown">
              <div v-show="!item.choose" style="float: right;height: 15px;padding-bottom:10px;padding-right:10px;" @click="show(index)"><i class="el-icon-arrow-down"></i></div>
              <div v-show="item.choose" style="float: right;height: 15px;padding-bottom:10px;padding-right:10px;" @click="show(index)"><i class="el-icon-arrow-up"></i></div>
              <div class="dropdown-content" v-show="item.choose">
                <template class="dropdown"> 
                  <div style="margin-left:5px" v-for="(itm,idx) in item.organizationInfoVos" :key="idx">
                    <p style="padding: 5px 0;" @click="childs(index,idx)">
                      <span v-if="itm.orgId">{{itm.orgName}}</span>
                      <span v-else><input class="input" placeholder="请输入" v-model="itm.orgName" width="50%" /></span>
                      <label style="float: right;" v-show="!item.del">
                        <label @click.stop="addListInfo(`2`,index,idx)">
                          <svg-icon icon-class="添加_add" style="width: 1.3em;height: 1.3em;" />
                        </label>
                        <span @click.stop="dialog(itm.orgId)" v-if="itm.orgId"><svg-icon icon-class="delete-three" style="width: 1.3em;height: 1.3em;" /></span>
                      </label>
                    </p>
                    <div style="margin-left:10px" v-show="itm.choose" v-for="(content,num) in itm.organizationInfoVos" :key="num">
                      <p style="padding: 5px 0;" @click="childs(index,idx,num)" >
                      <span v-if="content.orgId">{{content.orgName}}</span>
                      <span v-else><input class="input" placeholder="请输入" v-model="content.orgName" width="50%" /></span>
                        <label style="float: right;" v-show="!item.del">
                          <label @click.stop="addListInfo(`3`,index,idx,num)">
                            <svg-icon icon-class="添加_add" style="width: 1.3em;height: 1.3em;" />
                          </label>
                          <span @click.stop="dialog(content.orgId)" v-if="content.orgId"><svg-icon icon-class="delete-three" style="width: 1.3em;height: 1.3em;" /></span>
                        </label>
                      </p>
                      <div style="margin-left:10px" v-show="content.choose" v-for="(info,nuber) in content.organizationInfoVos" :key="nuber">
                        <p style="padding: 5px 0;" @click="child(index,idx,num,nuber)">
                          <span v-if="info.orgId">{{info.orgName}}</span>
                          <span v-else><input class="input" placeholder="请输入" v-model="info.orgName" width="50%" /></span>
                          <label style="float: right;" v-show="!item.del">
                            <label @click.stop="addListInfo(`4`,index,idx,num,nuber)">
                              <svg-icon icon-class="添加_add" style="width: 1.3em;height: 1.3em;" />
                            </label>
                            <span @click.stop="dialog(info.orgId)" v-if="info.orgId"><svg-icon icon-class="delete-three"  style="width: 1.3em;height: 1.3em;" /></span>
                          </label>
                        </p>
                        <div style="margin-left:10px" v-show="info.choose">
                          <p style="padding: 5px 0;" v-for="(data,dataNuber) in info.organizationInfoVos" :key="dataNuber">
                            <span v-if="data.orgId">{{data.orgName}}</span>
                            <span v-else><input class="input" placeholder="请输入" v-model="data.orgName" width="50%" /></span>
                            <label style="float: right;" v-show="!item.del">
                              <span @click="dialog(data.orgId)" v-if="data.orgId"><svg-icon icon-class="delete-three" style="width: 1.3em;height: 1.3em;" /></span>
                            </label>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </template>
              </div>
            </div>
          </div>
        </el-col>
        <el-col :span="6" v-show="addstate">
          <div class="box-card" :model="departmentInfo">
            <div class="header">
              <input class="input" placeholder="请输入" v-model="departmentInfo.orgName" width="50%" />
              <label style="float: right;">
                <span @click="increase"><svg-icon icon-class="添加_add" /></span>
                <span @click="submit"><i class="el-icon-circle-check" style="color: #aedd80;"></i></span>
              </label>
              <div style="margin-top: 5px;">设备数：{{departmentInfo.equipmentNumber}}</div>
            </div>
            <div class="dropdown">
              <div v-show="!this.addstats" style="float: right;height: 15px;padding-bottom:10px;padding-right:10px;" @click="addshow()"><i class="el-icon-arrow-down"></i></div>
              <div v-show="this.addstats" style="float: right;height: 15px;padding-bottom:10px;padding-right:10px;" @click="addshow()"><i class="el-icon-arrow-up"></i></div>
              <!-- <div style="float: right;height: 15px;padding-bottom:10px" @click="addshow()">鼠标移动到我这！</div> -->
              <div class="dropdown-content" v-show="this.addstats">
                <template class="dropdown"> 
                  <div style="margin-left:5px;">
                    <div v-for="(item,index) in departmentInfo.organizationInfoVos" :key="index" style="padding: 5px 0;" >
                      <span><input class="input" placeholder="请输入" v-model="item.orgName" width="50%" /></span>
                      <label style="float: right;" @click="adjunction(`1`,index)">
                        <svg-icon icon-class="添加_add" />
                      </label>
                      <div style="margin-left:10px;" v-for="(content,num) in item.organizationInfoVos" :key="num">
                        <span><input class="input" placeholder="请输入" v-model="content.orgName" width="50%" />
                          <label style="float: right;" @click="adjunction(`2`,index,num)">
                            <svg-icon icon-class="添加_add" />
                          </label>
                        </span>
                        <div style="margin-left:10px;" v-for="(info,nuber) in content.organizationInfoVos" :key="nuber">
                          <span>
                            <input class="input" placeholder="请输入" v-model="info.orgName" width="50%" />
                            <label style="float: right;" @click="adjunction(`3`,index,num,nuber)">
                              <svg-icon icon-class="添加_add" />
                            </label>
                          </span>
                          <div style="margin-left:10px;" v-for="(data,dataNuber) in info.organizationInfoVos" :key="dataNuber">
                            <span>
                              <input class="input" placeholder="请输入" v-model="data.orgName" width="50%" />
                              <!-- <label style="float: right;">
                                <svg-icon icon-class="delete-three" />
                              </label> -->
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </template>
              </div>
            </div>
          </div>
        </el-col>
      </el-row>
      <el-dialog
        title="确认删除"
        :visible.sync="dialogVisible"
        width="30%">
        <span>确认删除后，该层级下的全部内容将清除，请确认是否删除？</span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="strike">确 定</el-button>
        </span>
      </el-dialog>
    </div>
  </div>
</div>
</template>
<script>
import {getBGList,deleteRegion,saveRegion} from "@/tools/index"
export default {
  data() {
    return {
      name: '',
      addstate:false,
      dialogVisible: false,
      Business:null,
      modelObj: {},
      addList:[{orgName:"",organizationInfoVos:[]},{orgName:"",organizationInfoVos:[]},],
      departmentInfo:{
        equipmentNumber:'',
        organizationInfoVos:[
        ]
      },
      addstats:false,
      list:[]
    };
  },
  created(){
    this.listInfo()
  },
  methods:{
    submit(){
      saveRegion(this.departmentInfo).then(res=>{
        this.departmentInfo={
          equipmentNumber:'',
          organizationInfoVos:[]
        }
        })
      this.addstate = false
      this.listInfo()
    },
    confirm(index){
      saveRegion(this.list[index])
      this.list[index].del = true
      this.listInfo()
    },
    addListInfo(info,index,idx,num,nuber){
      if(info==1){//"pid":this.list[index].orgId,
        this.list[index].organizationInfoVos.push({"orgName": "","choose":true,"del":true,"organizationInfoVos":[]})
      }else if(info==2){//"pid":this.list[index].organizationInfoVos[idx].orgId,
        this.list[index].organizationInfoVos[idx].organizationInfoVos.push({"orgName": "","choose":true,"del":true,"organizationInfoVos":[]})
      }else if(info==3){//"pid":this.list[index].organizationInfoVos[idx].organizationInfoVos[num].orgId,
        this.list[index].organizationInfoVos[idx].organizationInfoVos[num].organizationInfoVos.push({"orgName": "","choose":true,"del":true,"organizationInfoVos":[]})
      }else{//"pid":this.list[index].organizationInfoVos[idx].organizationInfoVos[num].organizationInfoVos[nuber].orgId,
        this.list[index].organizationInfoVos[idx].organizationInfoVos[num].organizationInfoVos[nuber].organizationInfoVos.push({"orgName": "","choose":true,"del":true,})
      }
    },
    increase(){
      this.departmentInfo.organizationInfoVos.push({"orgName": "","organizationInfoVos":[]})
    },
    adjunction(idx,index,num,nuber){
      if(idx==1){
        this.departmentInfo.organizationInfoVos[index].organizationInfoVos.push({"orgName": "","organizationInfoVos":[]})
      }else if(idx==2){
        this.departmentInfo.organizationInfoVos[index].organizationInfoVos[num].organizationInfoVos.push({"orgName": "","organizationInfoVos":[]})
      }else{
        this.departmentInfo.organizationInfoVos[index].organizationInfoVos[num].organizationInfoVos[nuber].organizationInfoVos.push({"orgName": "",})
      }
    },
    dialog(orgId){
      this.dialogVisible = true
      this.orgId = orgId
    },
    //数据查询
    listInfo(){
      getBGList().then((res)=>{
        this.list = res
      })
    },
    addshow(){
      this.addstats = !this.addstats
    },
    show(index){
      if(this.list[index].choose == false){
        this.list[index].choose = true
      }else{
        this.list[index].choose = false
      }
    },
    childs(index,idx,num){
      if(num>-1){
        this.list[index].organizationInfoVos[idx].organizationInfoVos[num].choose = !this.list[index].organizationInfoVos[idx].organizationInfoVos[num].choose
      }else{
        this.list[index].organizationInfoVos[idx].choose = !this.list[index].organizationInfoVos[idx].choose
      }
    },
    child(index,idx,num,nuber){
      if(nuber>-1){
        this.list[index].organizationInfoVos[idx].organizationInfoVos[num].organizationInfoVos[nuber].choose = 
        !this.list[index].organizationInfoVos[idx].organizationInfoVos[num].organizationInfoVos[nuber].choose
      }
    },
    strike(){
      this.dialogVisible = false
      deleteRegion(
        this.orgId
      ).then(()=>{
        this.listInfo()
      })
    },
    edit(index){
      this.list[index].del = false
    }
  }
}
</script>
<style lang="scss" scoped>
::-webkit-scrollbar {
  width: 0 !important;height: 0;
}
::v-deep .el-dropdown{
  font-size: 16px;
}
.header {
  padding: 18px 20px;
  font-size: 16px;
  box-sizing: border-box;
  .icon{
    font-size: 14px;
    background: none;
    color: #409eff;
    border: none;
  }
}
.input{
  border: none;
  background: none;
  color: #FFF;
}
::v-deep .el-col-6 {
  width: 20%;
}
::v-deep .el-button--info {
  color: #FFF;
  background-color: #90939900;
  border-color: #909399;
}
::v-deep .el-input {
  position: relative;
  font-size: 14px;
  display: inline-block;
  width: 50%;
}
::v-deep .el-textarea__inner,::v-deep  .el-input__inner{
    background: transparent;
    color: #fff;
   }
.rooms{
  background-color: rgba(6, 27, 58, 1);
  color: azure;
  box-sizing: border-box;
  .room{
    width: 80%;
    margin: auto;
    height: calc(100vh - 80px);
    overflow-y: auto;
    scrollbar-width: thin;
    color: azure;
    .info{
      margin-top: 20px;
      padding: 0 20px;
      .box-card{
        border-top: #409eff solid 2px;
        border-bottom: none;
        background-color: #262c34;
        color: #FFF;
        border-radius: 0 0 10px 10px;
        margin-bottom: 20px;
        .dropdown {
          position: relative;
          display: inline-block;
          width: 100%;
        }
        .dropdown-content {
          display: block;
          position: absolute;
          background-color: #f9f9f9;
          box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
          width: 100%;
          margin-top: 25px;
          background: #1b2636;
          border-radius: 0 0 10px 10px;
          z-index: 99;
        }
        // .dropdown:hover .dropdown-content {
        //   display: block;
        // }
      }
      .add{
        height: 80px;
        background: red;
      }
    }

    .section{
      margin-top: 20px;
      height: 80px;
      .font{
        line-height: 80px;
        font-size: 26px;
        padding-left:20px;
      }
    }
  }
}
</style>