<template>
  <div class="manage">
    <div class="users">
      <div class="user">
        <section>
          <label>用户管理</label>
          <el-button type="primary" @click="edit(`add`)">新增</el-button>
          <!-- <el-button type="primary">导入</el-button>
          <span>下载导入模板</span> -->
        </section>
        <section>
          <el-input
            class="float"
            v-model="name"
            placeholder="输入用户姓名关键字"
            @change="search"
          >
            <i slot="prefix" class="el-icon-search" style="line-height: 40px;font-size:150%"></i>
          </el-input>
        </section>
      </div>
      <el-table
        :header-cell-style="{'text-align':'center'}"
        :cell-style="{'text-align':'center'}"
        border
        :data="tableData"
        :key="tableKey"
        style="width: 100%">
        <el-table-column label="序号" fixed type="index" width="80px">
        </el-table-column>
        <el-table-column label="工号" fixed width="100" prop="userCode">
        </el-table-column>
        <el-table-column prop="userName" fixed label="姓名" width="100">
        </el-table-column>
        <el-table-column prop="orgName" label="事业群" width="150" >
        </el-table-column>
        <el-table-column prop="regionName" label="区域" width="100" >
        </el-table-column>
        <el-table-column prop="areaName" label="园区" width="150" >
        </el-table-column>
        <el-table-column prop="buildName" label="楼栋" width="100" >
        </el-table-column>
        <el-table-column label="角色" width="200" >
          <template slot-scope="scope">
            <!-- <el-button type="primary" size="small">{{scope.row.role}}</el-button> -->
            <div class="exp">{{scope.row.roleDescribe}}</div>
          </template>
        </el-table-column>
        <el-table-column prop="createName" label="添加人" width="150" >
        </el-table-column>
        <el-table-column
          prop="createTime"
          label="添加时间" width="250"
          >
        </el-table-column>
        <el-table-column label="是否启用" width="100" >
          <template slot-scope="scope">
            <el-switch v-model="scope.row.state" @change="AuditRole(scope.row.userOrgId,scope.row.state)"></el-switch>
          </template>
        </el-table-column>
        <el-table-column label="操作" fixed="right" width="200px">
          <template slot-scope="scope">
            <span @click="edit(`edit`,scope.$index)" class="edit">编辑</span>
            <span @click="strike(scope.row.userOrgId)" class="strike">删除</span>
          </template>
        </el-table-column>
      </el-table>
      <el-dialog
        :title="info"
        :visible.sync="centerDialogVisible"
        width="800px"
        center>
        <el-row :gutter="20">
          <el-form label-position="right" label-width="80px" :model="formLabelAlign" :rules="rules" ref="ruleForm" style="width:100%;margin: auto;" >
            <el-col :span="12">
              <el-form-item label="工号" > <!-- prop="userCode" -->
                <el-input v-model="formLabelAlign.userCode" :disabled="disabled" @change="userCode"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="姓名"><!-- prop="userName" -->
                <el-input v-model="formLabelAlign.userName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="事业群">
                <el-select v-model="formLabelAlign.orgName" placeholder="请选择" style="width:100%;" value-key="orgId">
                  <el-option
                    v-for="(item,index) in orgList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                    @click.native="optionClick(item.orgName,item.orgId,index)">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="区域">
                <el-select v-model="formLabelAlign.regionName" placeholder="请选择" style="width:100%;">
                  <el-option
                    v-for="(item,index) in regionNameList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                    @click.native="optionregionClick(item.orgName,item.orgId,index)">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="园区">
                <el-select v-model="formLabelAlign.areaName" placeholder="请选择" style="width:100%;">
                  <el-option
                    v-for="(item,index) in areaNameList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                    @click.native="optionAreaClick(item.orgName,item.orgId,index)">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="楼栋">
                <el-select v-model="formLabelAlign.buildName" placeholder="请选择" style="width:100%;">
                  <el-option
                    v-for="item in buildNameList"
                    :key="item.orgId"
                    :label="item.orgName"
                    :value="item.orgId"
                    @click.native="optionBuildClick(item.orgName,item.orgId)">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="角色"><!-- prop="roleDescribe" -->
                <el-select v-model="formLabelAlign.roleDescribe" placeholder="请选择" style="width:100%;">
                  <el-option
                    v-for="item in roleList"
                    :key="item.roleId"
                    :label="item.roleDescribe"
                    :value="item.roleId"
                    @click.native="optionroleClick(item.roleDescribe,item.roleId)">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-form>
        </el-row>
        <span slot="footer" class="dialog-footer">
          <el-button type="primary" @click="save">保 存</el-button>
          <el-button @click="centerDialogVisible = false">关 闭</el-button>
        </span>
      </el-dialog>
      <div class="pagination">
        <el-pagination         
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[5,10]"
          :page-size="pageSize"
          layout="total, prev, pager, next, jumper"
          :total="totalSize">
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import {selectUserAuditList,saveOrUpdateStaff,selectOrgInfoList,getUserRole,queryStaffInformation,deleteStaffInfo,getDropDownOptions,stopAuditRole} from "@/tools/index"
export default {
  data() {
    return {
      centerDialogVisible: false,
      disabled:false,
      name: '',
      state:'',
      info:"",
      pageSize:10,
      totalSize:null,
      currentPage:1,//当前页数
      tableData: [],
      formLabelAlign: {"userOrgId":"","userRoleId":"","roleId":"","userId":"","orgId":"","regionId":"","areaId":"","buildId":"","userCode":"","state":"","userName":"",
      "orgName":"","regionName":"","areaName":"","buildName":null,"roleDescribe":"","createName":"","createTime":""},
      tableKey:1,
      orgList:[],
      regionNameList:[],
      areaNameList:[],
      buildNameList:[],
      roleList:[],
      rules: {
        userCode: [
          { required: true, message: '请输入工号', trigger: 'blur' },
          { min: 6, max: 8, message: '长度在 6 到 8 个字符', trigger: 'blur' }
        ],
        userName:[
          { required: true, message: '请输入姓名', trigger: 'blur' },
        ],
        roleDescribe: [
          { required: true, message: '请选择角色权限', trigger: 'change' }
        ],
      }
    };
  },
  created(){
    selectOrgInfoList().then(res=>{
      this.orgList = res
    })
    getUserRole().then(res=>{
      this.roleList = res
    })
    selectUserAuditList({
      "orgId": 0,
      "orgName": "",
      "pageRequest": {
        "order": "",
        "pageIndex": this.currentPage,
        "pageSize": this.pageSize,
        "prop": ""
      },
    }).then(res=>{
      this.tableData = res.content
      this.totalSize= res.totalSize
    })
  },
  watch:{
    state(){
      if(this.state=="add"){
        this.formLabelAlign={"userOrgId":"","userRoleId":"","roleId":"","userId":"","orgId":"","regionId":"","areaId":"","buildId":"","userCode":"","state":"","userName":"","orgName":"","regionName":"","areaName":"","buildName":null,"roleDescribe":"","createName":"","createTime":""}
        this.regionNameList=[],
        this.areaNameList=[],
        this.buildNameList=[]
      }else if(this.state=="edit"){
      if(this.formLabelAlign.orgId){
        getDropDownOptions({orgId:this.formLabelAlign.orgId}).then(res=>{
          this.regionNameList = res
        })
      }
      if(this.formLabelAlign.regionId){
        getDropDownOptions({orgId:this.formLabelAlign.regionId}).then(res=>{
          this.areaNameList = res
        })
      }
      if(this.formLabelAlign.areaId){
        getDropDownOptions({orgId:this.formLabelAlign.areaId}).then(res=>{
          this.buildNameList = res
        })
      }
      }
    }
  },
  methods:{
    optionClick(val,id,index){this.formLabelAlign.orgName=val,this.formLabelAlign.orgId=id,
      this.formLabelAlign.regionName="",this.formLabelAlign.regionId="",this.areaNameList=[]
      this.formLabelAlign.areaName="",this.formLabelAlign.areaId="",this.buildNameList=[]
      this.formLabelAlign.buildName="",this.formLabelAlign.buildId="",this.regionNameList=[]
      getDropDownOptions({orgId:this.formLabelAlign.orgId}).then(res=>{
        this.regionNameList  = res
      })
    },
    optionregionClick(val,id,index){this.formLabelAlign.regionName=val,this.formLabelAlign.regionId=id,
      this.formLabelAlign.areaName="",this.formLabelAlign.areaId="",this.buildNameList=[]
      this.formLabelAlign.buildName="",this.formLabelAlign.buildId="",this.areaNameList=[]
      getDropDownOptions({orgId:this.formLabelAlign.regionId}).then(res=>{
        this.areaNameList  = res
      })
    },
    optionAreaClick(val,id,index){this.formLabelAlign.areaName=val,this.formLabelAlign.areaId=id,
      this.formLabelAlign.buildName="",this.formLabelAlign.buildId="",this.buildNameList=[]
      getDropDownOptions({orgId:this.formLabelAlign.areaId}).then(res=>{
        this.buildNameList  = res
      })
    },
    optionBuildClick(val,id,index){this.formLabelAlign.buildName=val,this.formLabelAlign.buildId=id,console.log(id)},
    optionroleClick(val,id){this.formLabelAlign.roleDescribe=val,this.formLabelAlign.roleId=id},
    AuditRole(id,state){
      let typeState
      if(state==true){
        typeState = 1
      }else{
        typeState = 2
      }
      stopAuditRole(id,typeState).then(res=>{
        this.$message({
          showClose: true,
          message: '状态切换成功',
          type: 'success',
          offset:80,
        });
      })
    },
    handleSizeChange(val) {
      this.pageSize = val
      this.search()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.search()
    },
    search(){
      selectUserAuditList({
        orgId: 0,
        userName: this.name,
        pageRequest: {
          order: "",
          pageIndex: this.currentPage,
          pageSize: this.pageSize,
          prop: ""
        },
      }).then(res=>{
        this.tableData = res.content
        this.totalSize= res.totalSize
        this.tableKey = Math.random()
      })
    },
    userCode(){
      queryStaffInformation({
        userCode:this.formLabelAlign.userCode
      }).then(res=>{
        if(res.code == 100){
          this.formLabelAlign.userId = res.data.userId
          this.formLabelAlign.userName = res.data.userName
        }else{
          this.formLabelAlign.userCode=""
          this.$message.warning("工号不存在")
        }
      })
    },
    strike(userOrgId){
      deleteStaffInfo(userOrgId).then(res=>{
        this.$message.success("删除成功")
        this.tableKey = Math.random()
        this.search()()
      })
    },
    edit(state,index){
      if(state=="edit"){
        this.info="编辑用户信息"
        this.state = state
        this.disabled = true
        this.formLabelAlign = JSON.parse(JSON.stringify(this.tableData[index]))
      }else{
        this.info="新增用户信息"
        this.state = state
        this.disabled = false
        this.formLabelAlign =  {"userOrgId":"","userRoleId":"","roleId":"","userId":"","orgId":"","regionId":"","areaId":"","buildId":null,"userCode":"","state":"","userName":"",
          "orgName":"","regionName":"","areaName":"","buildName":null,"roleDescribe":"","createName":"","createTime":""}
        }
      this.centerDialogVisible=true
    },
    save(){
      if(this.state == "add"){
        saveOrUpdateStaff({
          orgIds:[this.formLabelAlign.orgId,this.formLabelAlign.areaId,this.formLabelAlign.regionId,this.formLabelAlign.buildId],
          roleId:this.formLabelAlign.roleId,
          roleName: this.formLabelAlign.roleDescribe,
          userId:this.formLabelAlign.userId,
          userCode: this.formLabelAlign.userCode,
          userName: this.formLabelAlign.userName,
        },).then(res=>{this.search()})
        this.tableKey = Math.random()
        this.centerDialogVisible=false
      }
      if(this.state == "edit"){
        console.log("this.formLabelAlign.userRoleId",this.formLabelAlign.userRoleId)
        saveOrUpdateStaff({
          userRoleId:this.formLabelAlign.userRoleId,
          userOrgId:this.formLabelAlign.userOrgId,
          roleId:this.formLabelAlign.roleId,
          roleName: this.formLabelAlign.roleDescribe,
          userId:this.formLabelAlign.userId,
          userCode: this.formLabelAlign.userCode,
          userName: this.formLabelAlign.userName,
          orgIds:[this.formLabelAlign.orgId,this.formLabelAlign.areaId,this.formLabelAlign.regionId,this.formLabelAlign.buildId],
        }).then(res=>{this.search()})
        this.tableKey = Math.random()
        this.centerDialogVisible=false
      }
    }
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-input.is-disabled .el-input__inner {
  background-color: #F5F7FA00;
}
::v-deep .el-dialog {
  position: relative;
  margin: 0 auto 50px;
  background: #0f274c;
  border-radius: 20px;
  box-shadow: 0 1px 3px rgba(0,0,0,.3);
  box-sizing: border-box;
}
::v-deep .el-dialog__body {
  color: #ffffff;
  font-size: 14px;
  word-break: break-all;
}
::v-deep .el-dialog__title {
  line-height: 24px;
  font-size: 18px;
  color: #ffffff;
}
::v-deep .el-form-item__label {
  text-align: right;
  vertical-align: middle;
  float: left;
  font-size: 14px;
  color: #ffffff;
  line-height: 40px;
  padding: 0 12px 0 0;
  box-sizing: border-box;
}
::v-deep .el-table,::v-deep .el-table tr,::v-deep .el-table td {
    background-color: #061b3a;
    color: #fff;
}
::v-deep .el-table tbody tr:hover>td {
  background-color:#3790b3!important;
}
::v-deep .el-table__body tr.hover-row.current-row>td,::v-deep .el-table__body tr.hover-row.el-table__row--striped.current-row>td,::v-deep .el-table__body tr.hover-row.el-table__row--striped>td,::v-deep .el-table__body tr.hover-row>td{
    background-color:#3790b3
}
::v-deep .el-table th{
  background: #1b2636;
}
::v-deep .el-table .el-table__cell {
  padding: 5px 5px;
  min-width: 0;
  box-sizing: border-box;
  text-overflow: ellipsis;
  vertical-align: middle;
  position: relative;
  text-align: left;
}
.pagination{
	justify-self: center;
	align-self: center;
  margin: 20px;
  float: right;
}
  .exp{ 
    border:1px solid rgb(0, 0, 0);
    background: #409eff;
    border-radius:5px;
    padding: 5px 0;
    }
  .edit{
    float: left;
    color: #3484d9;
    padding-left: 30px;
  }
  .strike{
    float: right;
    color: #f56c6c;
    padding-right: 30px;
  }
::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 4px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 1px;
}
::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(97, 184, 179, 0.1);
  background: rgba(6, 27, 58, 1);
}
::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(87, 175, 187, 0.1);
  border-radius: 10px;
  background: #ededed;
}
::v-deep .el-textarea__inner,::v-deep  .el-input__inner{
        background: transparent;
        color: #fff;
   }
.manage{
  background-color: rgba(6, 27, 58, 1);
}
.users{
  width: 80%;
  margin: auto;
  height: calc(100vh - 80px);
  overflow: auto;
  scrollbar-width: thin;
  .user{
    display: flex;
    height: 80px;
    section{
      width: 50%;
      line-height: 80px;
    }
  }
}
.float{
  float: right;
  width: 50%;
  min-width: 300px;
  z-index: 1;
}
</style>