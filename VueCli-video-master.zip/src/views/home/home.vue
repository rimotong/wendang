<template>
  <div class="demand">
    <el-container>
      <el-container>
        <el-aside width="300px" class="aside">
          <el-tabs v-model="activeName" stretch @tab-click="handleClick">
            <el-tab-pane label="在线设备" name="first"><Equipment></Equipment></el-tab-pane>
            <el-tab-pane label="录制视频" name="third"><Transcribe v-if="activeName==='third'"></Transcribe></el-tab-pane>
          </el-tabs>
        </el-aside>
        <el-container>
          <el-header class="header">
            <span @click="update(1)" style="font-size: 20px;" ><svg-icon :class="{'icon': numbers== 1}" icon-class="一格" /></span>
            <span @click="update(4)" style="font-size: 20px;" ><svg-icon :class="{'icon': numbers== 4}" icon-class="四格" /></span>
            <span @click="update(9)" style="font-size: 20px;" ><svg-icon :class="{'icon': numbers== 9}" icon-class="九格" /></span>
          </el-header>
          <el-main>
            <router-view v-if="activeName=='first'"></router-view>
            <!-- <Videos v-if="activeName=='first'" :numbers="numbers"></Videos> -->
            <VideoPlayer v-if="activeName=='third'" ></VideoPlayer>
          </el-main>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>
<script>
import VideoPlayer from "@/components/liveFlvupload.vue"
import Videos from "@/views/home/componenrs/Videos.vue"
import Equipment from "../home/componenrs/tabs/Equipment.vue"
import Grouping from "../home/componenrs/tabs/grouping.vue"
import Transcribe from '../home/componenrs/tabs/Transcribe.vue';
import { mapState,mapActions } from 'pinia'
import storeId  from '@/store'
export default {
  components: {
    Videos,Equipment,Grouping,Transcribe,VideoPlayer
  },
  watch:{
    numbers:{
      handler(){
      if(this.activeName == 'first'){
        if(this.numbers == 1){
          this.$router.push("/video")
        }
        if(this.numbers == 4){
          this.$router.push("/video4")
        }
        if(this.numbers == 9){
          this.$router.push("/video9")
        }
      }},
      immediate: true
    }
  },
  data() {
    return {
      activeName: 'first',
    };
  },
  computed: {
    ...mapState(storeId, ['numbers',]),
  },
  methods: {
    ...mapActions(storeId, ['numbers'],),
    handleClick(tab, event) {
      console.log(tab, event);
    },
    update(num){
      const store = storeId()
      store.$patch((state) => {
        state.numbers = num
      })
      console.log(this.numbers ,"sdfsd")
    },
    goApplication() {
      this.leftNavstate = 0;
      this.$router.push({
        path: "/application",
        query: {},
      });
    },
    goDrafts() {
      this.leftNavstate = 1;
      this.$router.push({
        path: "/drafts",
      });
    },
    goUserSign() {
      this.leftNavstate = 2;
      this.$router.push({
        path: "/userSign",
      });
    },
  },
};
</script>
<style lang="scss" scoped>
* {
  margin: 0;
  padding: 0;
}
::-webkit-scrollbar {
  /*滚动条整体样式*/
  width: 4px; /*高宽分别对应横竖滚动条的尺寸*/
  height: 1px;
}
::-webkit-scrollbar-thumb {
  /*滚动条里面小方块*/
  border-radius: 10px;
  box-shadow: inset 0 0 5px rgba(97, 184, 179, 0.1);
  background: rgba(6, 27, 58, 1);
}
::-webkit-scrollbar-track {
  /*滚动条里面轨道*/
  box-shadow: inset 0 0 5px rgba(87, 175, 187, 0.1);
  border-radius: 10px;
  background: #ededed;
}
::v-deep .el-tabs__item {
  padding: 0 10px;
  height: 40px;
  box-sizing: border-box;
  line-height: 40px;
  display: inline-block;
  list-style: none;
  font-size: 14px;
  font-weight: 100%;
  color: #ffffff;
  position: relative;
}

.icon {
  color: #00FFFF;
}

.demand {
  scrollbar-width: thin;
  height: calc(100vh - 80px) !important;
  display: flex;
  .aside{
    background-color: rgba(28, 39, 55, 1);
    color: #ffffff;
    overflow-x: auto;
  }
  .header{
    background-color:rgb(8, 31, 65);
    span{
      margin-left: 20px;
      // color: #ffffff;
      line-height: 60px;
    }
  }
  .lfnav {
    list-style: none;
    width: 200px;
    height:100%;
    background: #eff2f9;
    li {
      // padding-left: 16px;
      cursor: pointer;
      height: 57px;
      font-size: 20px;
      line-height: 57px;
      color: #333333;
    }
  }
  .lfnav_color {
    background: #ffffff;

    color: #002f75;

    border-left: 14px solid #002f75;
  }
}
</style>
