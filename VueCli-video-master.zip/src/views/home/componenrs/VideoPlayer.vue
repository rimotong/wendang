<template>
  <div class="videoShow">
    <video id="videoElement" autoplay muted width="100%" height="99%">
    </video>
    <div class="video-img"><el-button type="primary" size="mini" round @click="cutLargreen(`videoElement`)">点击截图</el-button></div>
    <div class="video-add"><el-button type="primary" size="mini" round @click="btnFullSrc(`videoElement`)">点击全屏</el-button></div>
  </div>
</template>
 
<script>
import flvjs from 'flv.js'
export default {
  props:{
    videoUrl:{
      type:String,
      default:``
    }
  },
  data () {
    return {
	    flvPlayer:null,
      imagesUrl: [],
      Url:null,
    }
  },
  watch:{
    videoUrl:{
      handler(v){
        this.Url = v
      },
      depp:true,
      immediate:true
    }
  },
  computed: {
	// 2.防止命中缓存
  	dealVideoUrl() {
		  return this.videoUrl + '?time=' + new Date().valueOf()
	  }
  },
  beforeDestroy () {
    this.flvPlayer.destroy()
  },
  mounted() {
      let _this = this;
      if (flvjs.isSupported()) {
        var videoElement = document.getElementById('videoElement');
        this.flvPlayer = flvjs.createPlayer({
          type: 'flv',
          isLive: true,
          // hasAudio: true,
          // hasVideo:true, //流中是否有视频轨道
          stashInitialSize: 128,// 减少首桢显示等待时长   //指示IO暂存缓冲区的初始大小。默认值为384KB。指出合适的尺寸可以改善视频负载/搜索时间。
          header:"Access-Control-Allow-Origin: *",
          url:`http://10.125.129.6/live/${window.btoa(this.Url)}/live.flv`,
        });
        this.flvPlayer.attachMediaElement(videoElement);
        this.flvPlayer.load();
		    this.flvPlayer.play();
        //优化
        // 【重要事件监听】http请求建立好后，该事件会一直监听flvjs实例
        this.flvPlayer.on(flvjs.Events.STATISTICS_INFO, (res) => {
          if (_this.changeLampPost) { // 离开路由或切换设备
            // 销毁实例
            _this.flvPlayer.pause();
            _this.flvPlayer.unload();
            _this.flvPlayer.detachMediaElement();
            _this.flvPlayer.destroy();
            _this.flvPlayer= null;
          }
        })
      }
    },
    methods:{
      //全屏播放
      btnFullSrc(id){
        const elVideo = document.getElementById(id);
        if(elVideo.requestFullScreen){
          elVideo.requestFullScreen();
          elVideo.play();
        }//fireFox
        else if(elVideo.mozRequestFullScreen){
          elVideo.mozRequestFullScreen();
          elVideo.play();
        }//chrome
        else if(elVideo.webkitRequestFullScreen){
          elVideo.webkitRequestFullScreen();
          elVideo.play();
        }
      },
      cutLargreen(id){
        var player = document.getElementById(id);   //获取video的Dom节点
        player.setAttribute("crossOrigin", "anonymous");  //添加srossOrigin属性，解决跨域问题
        var canvas = document.createElement("canvas");
        var img = document.createElement("img");
        canvas.width = player.clientWidth;
        canvas.height = player.clientHeight;
        canvas.getContext("2d").drawImage(player, 0, 0, canvas.width, canvas.height);//截
        var dataURL = canvas.toDataURL("image/png");  //将图片转成base64格式
        img.src = dataURL;
        img.width = player.clientWidth-200;   //控制截出来的图片宽的大小
        img.height = player.clientHeight-200; //控制截出来的图片高的大小
        img.style.border="1px solid #333333"   //控制截出来的图片边框的样式
        // document.getElementById("cutImage").appendChild(img);   //显示在页面中
        this.downFile(dataURL, "图片.jpg");   //下载截图
      },
    //下载截图
    downFile(data, fileName) {
          var save_link = document.createElementNS(
            "http://www.w3.org/1999/xhtml",
            "a"
          ); //有效的内部空间URI
          save_link.href = data;
          save_link.download = fileName;
          var event = document.createEvent("MouseEvents");
          event.initMouseEvent(
            "click",
            true,
            false,
            window,
            0,
            0,
            0,
            0,
            0,
            false,
            false,
            false,
            false,
            0,
            null
          );
          save_link.dispatchEvent(event);
        },
    },
    beforeDestroy () {
      this.player.destory();
    }
}
</script>
<style lang="scss" scoped>
::v-deep .el-button--primary {
  background-color: #40a0ff00;
  border-color: #409EFF;
}
.videoShow{
  height: 100%;
  position: relative;
  overflow-y: auto;
}
.video-img{
	position: absolute;
  top: 20%;
  left: 0%;
  bottom: 0;
  width: 100%;
  z-index: 999;
  background-size:100%;
  cursor:pointer;
}
.video-add{
  position: absolute;
  top: 40%;
  left: 0%;
  bottom: 0;
  width: 100%;
  z-index: 999;
  background-size:100%;
  cursor:pointer;
}
</style>