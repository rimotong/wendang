<template>
  <div id="container">
    <div id="photo"><img src="../../../assets/img/404.png" class="img" /></div>
    <div class="content">
      <div class="text">文字介绍
      <br/>新闻内容</div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
#container {width: 100%;position: relative; height:100%}
#photo {float: left; width: 50%;}
.content {float: right; width: 50%; 
 .text{
    color: rgb(0, 0, 0); 
    position:absolute;
    left:50%;
    top:50%;
    transform:translate(-50%,-50%);
 }} 
.img{
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}
</style>