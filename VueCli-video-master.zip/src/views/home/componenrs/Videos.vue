<template>
  <div class="video">
    <div v-if="show==1" style="height: 100%;">
      <video-player></video-player>
    </div>
    <div v-if="show==4" style="height: 100%;">
      <videos-4></videos-4>
    </div>
    <div v-if="show==9" style="height: 100%;">
      <div class="columns"> 
        <videos-9></videos-9>
      </div>
    </div>
  </div>
</template>

<script>
// import VideoPlayer from './VideoPlayer.vue'
import VideoPlayer from '@/components/flv.vue'
import Error from "./404.vue";
import Videos4 from './videos4.vue';
import Videos9 from './videos9.vue';
import { mapState,mapActions } from 'pinia'
import storeId  from '@/store'

export default {
  props:{
    numbers:{
      type:Number,
      default:"",
    }
  },
  watch:{
    VideoUrl:{
      handler(val) {
        this.Url = val
      },
      deep: true, // 深度监听
      immediate:true
    }
  },
  computed: {
    ...mapState(storeId, ['VideoUrl',]),
  },
  components:{Error,VideoPlayer, Videos4,Videos9},
  data() {
    return {
      Url:"",
      show:"",
      // deom1:`rtsp://admin:erc912511!!!@10.157.237.6:554/Streaming/Channels/101`,
      deom2:`rtsp://admin:erc912511!!!@10.157.237.7:554/Streaming/Channels/101`,
    };
  },
  watch:{
    numbers:{
      handler(v){
        this.show=JSON.parse(JSON.stringify(v))
        console.log("this.show",this.show)
      }
    }
  },
  beforeDestroy(){
    this.flvPlayer.destroy();
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-card__body,::v-deep  .el-main {
  padding: 0px;
}
.video{
  height: calc(100vh - 140px) !important;
  background-color: #061b3a;
  .room{
    height: 50%;
    width: 100%;
  }
  .double{
    background: aqua;
    width: 50%;
    height: 100%;
    float: left;
  }
  .doubles{
    background: rgb(255, 0, 0);
    width: 50%;
    height: 100%;
    float: left;
  }
  .columns{
    height: 100%;
    .three{
      // background: aqua;
      width: 33.33%;
      height: 33.33%;;
      float: left;
    }
  }

}
</style>