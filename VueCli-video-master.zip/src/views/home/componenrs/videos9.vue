<template>
  <div class="videos">
    <div v-for="(item,index) in VideoUrl9" :key="item.id" class="video" :style="{position:isFixed[index],width:width[index],height:height[index]}" v-show="item.show">
      <FourVideo v-if="item.id>0" :VideoUrl="item.src" :ImgName="item.name" :virtualVideoId="item.id" :recordUrl="item.recordUrl" :index="index" @state="state"
      ></FourVideo>
    </div>
    <div v-for="index of ImgLength" class="video" v-show="imgState">
      <img src="@/assets/img/noVideo.png" width="100%" height="100%" />
    </div>
  </div>
</template>
<script>
import FourVideo from "@/components/video.vue"
import { mapState,mapActions } from 'pinia'
import storeId  from '@/store'
//=> 引入flv.js
export default {
  components:{FourVideo},
  data() {
    return {
      isFixed:["relative","relative","relative","relative","relative","relative","relative","relative","relative",],
      height:["33%","33%","33%","33%","33%","33%","33%","33%","33%",],
      width:["33%","33%","33%","33%","33%","33%","33%","33%","33%",],
      imgState:true
    };
  },
  computed: {
    ...mapState(storeId, ['VideoUrl9','ImgName','numbers']),
    ImgLength(){
      return 9-this.VideoUrl9.length
    }
  },
  methods:{
    ...mapActions(storeId, ['virtualVideoUrl','virtualVideoId']),
    state(state,id,index){
      this.index
      this.id = id
      if (state=='relative') {
        //如果全屏退出全屏
        this.isFixed[index] = "relative";
        this.height[index] = '33%'
        this.width[index] = '33%'
        this.imgState = true
        this.VideoUrl9.forEach(item=>{
          item.show = true
        })
      } else {
        this.isFixed[index] = "fixed";
        this.height[index] = 'calc(100vh - 150px)'
        this.width[index] = '85%'
        this.imgState = false
        this.VideoUrl9.forEach((item,idx)=>{
          if(idx == index){
            item.show = true
          }else{
            item.show = false
          }
        })
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.my-disabled{
  z-index: 9999;
}
.videos{
  height: calc(100vh - 140px) !important;
  width: 100%;
  background-color: #061b3a;
  overflow: hidden;
  position: relative;
  .video{
    float: left;
    position:relative;
    width: 33%;
    height: 33%;
  }
  .video-img{
    position: absolute;
    top: 20%;
    left: 0%;
    bottom: 0;
    width: 100%;
    z-index: 999;
    background-size:100%;
    cursor:pointer;
  }
  .video-add{
    position: absolute;
    top: 40%;
    left: 0%;
    bottom: 0;
    width: 100%;
    z-index: 999;
    background-size:100%;
    cursor:pointer;
  }
}
</style>
