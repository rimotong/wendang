<template>
  <div>
    <el-row class="tac">
      <el-col :span="24">
        <el-menu
          default-active="1-1-1-1"
          background-color="#1c2737"
          text-color="#fff"
          active-text-color="#ffd04b">
          <!-- 引入组件 -->
          <menu-tree :menuData="onlineList"></menu-tree>
        </el-menu>
        <!-- <el-menu
          default-active="2"
          class="el-menu-vertical-demo"
          @open="handleOpen"
          background-color="#FFF0"
          text-color="#fff"
          >
          <el-submenu v-for="(item,index) in onlineList" :key="index" :index="index.toString()">
            <template slot="title">
              <span><el-checkbox v-model="checked" class="clik"></el-checkbox>{{item.orgName}}</span>
              <span style="float: right;padding-right: 15px;">8/10</span>
            </template>
            <el-menu-item-group>
              <span v-for="(ite,idx) in item.auditEquipmentListVos"  @click="update(index,idx)" :key="idx">
                <el-menu-item :index="index.toString()+'-'+idx.toString()">
                  <el-checkbox v-model="idx.choose" class="clik"></el-checkbox>{{ite.orgName}}
                </el-menu-item>
              </span>
            </el-menu-item-group>
          </el-submenu>
        </el-menu> -->
      </el-col>
    </el-row>
  </div>
</template>
<script>
import MenuTree from '@/components/MenuTree'
import { mapState,mapActions } from 'pinia'
import storeId  from '@/store'
import {getFLVList} from "@/tools/index"
import { type } from 'os'
export default {
  components: {
    MenuTree
  },
  data () {
    return {
      checked:true,
      onlineList:null,
    }
  },
  created(){
    getFLVList({
      type:1
    }).then((res)=>{
      this.onlineList = res
    })
  },
  methods:{
    ...mapActions(storeId, ['VideoUrl']),
    time() {
    var nowdate = new Date();
    var h = nowdate.getHours(),
        m = nowdate.getMinutes(),
        s = nowdate.getSeconds(),
        h = checkTime(h),
        m = checkTime(m),
        s = checkTime(s);
      return h +":" + m + ":" + s;
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    // handleClose(key, keyPath) {
    //   console.log(key, keyPath);
    // },
    // update(index,idx){
    //   const store = storeId()
    //   store.$patch((state) => {
    //     state.VideoUrl = this.onlineList[index].auditEquipmentListVos[idx].videoAddress
    //     state.ImgName = this.onlineList[index].auditEquipmentListVos[idx].orgName
    //   })
    // }
  }
}
</script>

<style lang="scss" scoped>
.clik{
  margin-top: -9px;
}
span{
  font-size: 18px;
}
::v-deep  .el-menu-item-group__title{
    padding: 0px 0 0px 20px;
    line-height: normal;
    font-size: 12px;
    color: #909399;
}
::v-deep.el-menu .el-menu-item:hover{
    outline: 0 !important;
    background: #2E95FB!important;
}
::v-deep.el-menu .el-menu-item.is-active {
  color: rgb(255, 255, 255);
  background: #2E95FB !important;
}
.el-submenu ::v-deep.el-submenu__title:hover {
  background: #2E95FB!important;
}
</style>