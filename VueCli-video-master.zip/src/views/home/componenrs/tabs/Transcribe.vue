<template>
  <div>
    <el-input
      v-model="name"
      placeholder="输入名称关键字"
      @change="search"
      style="width: 90%;margin-left:5%"
    >
      <i slot="prefix" class="el-icon-search" style="line-height: 40px;font-size:150%"></i>
    </el-input>
    <ul>
      <li v-for="(item,index) in list" :key="index"         
        @mouseover="changeImageSrc(index, 'hover')"
        @mouseleave="changeImageSrc(index,0)"
        @click="play(item.viewPath,item.valueId,index)">
          {{item.videosName}}
          <span class="span" v-show="!item.view">{{item.createVideosTime.split(' ')[1]}}</span>
          <span v-show="item.view" class="span">
            <!-- <i class="el-icon-edit" @click="download(index)"></i> <i class="el-icon-share" ></i> -->
            <span @click.stop="deletes(item.fileId)"><svg-icon icon-class="删除_delete" /></span>
          </span>
      </li>
    </ul>
    <div class="pagination">
      <el-pagination
        small         
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[10]"
        :pager-count="count"
        :page-size="pageSize"
        layout="prev, pager, next, jumper"
        :total="totalSize">
      </el-pagination>
    </div>
  </div>
</template>
<script>
import { mapState,mapActions } from 'pinia'
import storeId  from '@/store'
import {getFLVList,deleteFileVideos} from "@/tools/index"
export default {
  data() {
    return {
      pageSize:10,
      count:5,
      totalSize:null,
      currentPage:1,
      name: '',
      list:[
      ]
    };
  },
  created(){
    this.listDate()
  },
  methods:{
    ...mapActions(storeId, ['virtualVideoUrl','recordId']),
    handleSizeChange(val) {
      this.pageSize = val
      this.search()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.search()
    },
    search(){
      getFLVList({
        type:2,
        equipmentName:this.name,
        pageRequest: {
          order: "",
          pageIndex: this.currentPage,
          pageSize: this.pageSize,
          prop: ""
        },
      }).then((res)=>{
        this.list = res.content
        this.totalSize= res.totalSize
      })
    },
    listDate(){
      getFLVList({
        type:2,
        pageRequest: {
          order: "",
          pageIndex: 1,
          pageSize: 10,
          prop: ""
        },
      }).then((res)=>{
        this.list = res.content
        this.totalSize= res.totalSize
      })
    },
    play(viewPath,id,index){
      this.cutover = true
      this.videoIndexs = index
      const store = storeId()
      store.$patch((state) => {
        state.virtualVideoUrl = viewPath
        state.recordId = id
      })
      console.log("id",id)
    },
    changeImageSrc(key,val){
      if(val!=0){
        this.list[key].view= true
      }else{
        this.list[key].view= false
      }
    },
    download(key){
      alert("下载"+key)
    },
    deletes(id){
      deleteFileVideos(id).then(res=>{
        this.$message({
          showClose: true,
          message: '删除成功',
          type: 'success',
          offset:80,
        });
        const store = storeId()
        store.$patch((state) => {
          state.virtualVideoUrl = ""
          state.recordId = ""
        })
        this.search()
      })
    }
  }
}
</script>
<style lang="scss" scoped>
::v-deep .el-pager li {
  padding: 0 4px;
  background: none;
  color: #FFF;
  box-sizing: border-box;
}
::v-deep .el-pager li.active {
  color: #409EFF;
  cursor: default;
}
::v-deep .el-pagination .btn-next,::v-deep .el-pagination .btn-prev {
  background: center center no-repeat #FFF0;
  color: #05f;
}
::v-deep .el-pagination__jump {
  margin-left: 0px;
}
::v-deep .el-textarea__inner,::v-deep  .el-input__inner{
        background: transparent;
        color: #fff;
   }
  ul{
    list-style: none;
    li{
      font-size: 12px;
      margin-left: 5%;
      height: 40px;
      line-height: 40px;
    }
    li:hover{
      background-color:rgb(13,55,116);
    }
  }
  .span{
    float:right;
    margin-right: 15px;
  }
  i{
    margin-right: 5px;
  }
</style>