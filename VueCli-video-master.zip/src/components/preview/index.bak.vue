<template>
<div :style="'border:1px dashed;width:100%;height:300px;overflow:scroll'">
  <!-- word查看详情 -->
  <div id="wordView" v-html="vHtml" v-if="isWord"></div>
  <!-- excel查看详情 -->
  <div id="table" v-if="!isWord">
     <el-table :data="excelData" style="width: 100%">
        <el-table-column
            v-for="(value, key, index) in excelData[2]"
            :key="index"
            :prop="key"
            :label="key"
         ></el-table-column>
     </el-table>
  </div>
</div>
</template>
<script>
import mammoth from "mammoth";
import * as XLSX from 'xlsx'
export default {
data() {
  return {
    // 显示word excel
    vHtml: "",
    wordURL: "",
    isWord: "",
    fileType: "", // 1 word(.docx .doc) 2 excel(.xlsx .xsl) 3 其他()
    excelData: [],
    workbook: {},
    excelURL: "https://www.aconvert.com/cn/file.php?l=s9.aconvert.com/convert/p3r68-cdx67/gcygb-i8b0z.xls", //文件地址，看你对应怎末获取、赋值
  };
},
methods:{
   // 查看详情=列表操作
   // <el-button type="text" @click="handleDetail(scope.row)" v-if="!scope.row.havePassword">查看</el-button>
   handleDetail(row) {
      console.log(row, "查看row");
      this.tzOpen = true;
      this.detailForm = row;
      if (row.suffix === "docx" || row.suffix === "doc") {
        // this.fileType = 1;
        this.isWord = 1;
        // this.wordURL = row.url;
        this.readExcelFromRemoteFile(row.url);
      } else if (row.suffix === "xlsx" || row.suffix === "xls") {
        // this.fileType = 2;
        this.isWord = 0;
        // this.excelURL = row.url;
        this.readWorkbookFromRemoteFile(row.url);
      }
    },
// 在线查看excel文件
    readWorkbookFromRemoteFile: function (url) {
      var xhr = new XMLHttpRequest();
      xhr.open("get", url, true);
      xhr.responseType = "arraybuffer";
      let _this = this;
      xhr.onload = function (e) {
        if (xhr.status === 200) {
          var data = new Uint8Array(xhr.response);
          var workbook = XLSX.read(data, { type: "array" });
          console.log("workbook", workbook);
          var sheetNames = workbook.SheetNames; // 工作表名称集合
          _this.workbook = workbook;
          _this.getTable(sheetNames[0]);
        }
      };
      xhr.send();
    },
    // 在线查看word文件
    readExcelFromRemoteFile(url) {
      var vm = this;
      var xhr = new XMLHttpRequest();
      xhr.open("get", url, true);
      xhr.responseType = "arraybuffer";
      xhr.onload = function () {
        if (xhr.status == 200) {
          mammoth
            .convertToHtml({ arrayBuffer: new Uint8Array(xhr.response) })
            .then(function (resultObject) {
              vm.$nextTick(() => {
                // document.querySelector("#wordView").innerHTML =
                //   resultObject.value;
                vm.vHtml = resultObject.value;
              });
            });
        }
      };
      xhr.send();
    },
    getTable(sheetName) {
      console.log(sheetName);
      var worksheet = this.workbook.Sheets[sheetName];
      this.excelData = XLSX.utils.sheet_to_json(worksheet);
      console.log(this.excelData);
    },
}
}
</script>