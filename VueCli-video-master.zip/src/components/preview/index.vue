<template>
  <div class="home">
    <!-- <div ref="file"></div> -->
    <!-- <div class="my-component" ref="preview">
      <input type="file" @change="preview" ref="files">
    </div> -->
    {{fileName}}
    <!-- <div v-html="tableau"></div>预览在线表格 -->
    <pdf></pdf>
  </div>
</template>

<script>
// import * as XLSX from 'xlsx';
import pdf from "./pdf.vue"
const docx = require('docx-preview');
window.JSZip = require('jszip')
export default {
  props:{
    fileName:{
      type:String,
      default:""
    }
  },
  components:{pdf},
  data() {
    return {
      
    };
  },
  methods:{
    preview(e){
      docx.renderAsync(this.$refs.files.files[0],this.$refs.preview) // 渲染到页面预览
    }
  },
  // mounted(){
  //   axios({
  //     method: 'get',
  //     responseType: 'blob', // 设置响应文件格式
  //     url: '/docx',
  //   }).then(({data}) => {
  //     docx.renderAsync(data,this.$refs.file) // 渲染到页面预览
  //   }),
  //    axios.get('/xlsx',{
  //      responseType: "arraybuffer", // 设置响应体类型为arraybuffer
  //    }).then(({data})=> {
  //      let workbook = XLSX.read(new Uint8Array(data), {type:"array"}); // 解析数据
  //      var worksheet = workbook.Sheets[workbook.SheetNames[0]]; // workbook.SheetNames 下存的是该文件每个工作表名字,这里取出第一个工作表
  //      this.tableau = XLSX.utils.sheet_to_html(worksheet); // 渲染
  //    })
  // axios({
  //   method: 'get',
  //   responseType: 'blob', // 设置响应文件格式
  //   url: '/pdf',
  // })
  //   .then(res => {
  //     let blob = new Blob([res.data], {type: "application/vnd.ms-excel"})
  //     let objectUrl = URL.createObjectURL(blob)
  //     this.pathUrl = '../../../../../static/pdf/web/viewer.html?file=' + objectUrl
  //   })
  //   .catch(err => {
  //     console.log(err)
  //   })
  // }
}
</script>
<style lang="scss" scoped>
table {
    border-collapse:collapse;
    border:none;
    font-size:0.23rem;
}
td,th {
    width:1px;
    white-space:nowrap; /* 自适应宽度*/
    word-break:keep-all; /* 避免长单词截断，保持全部 */
    border:solid #d5d5d5 1px;
    text-align:center;
    white-space:pre-line;
    display:table-cell;
    vertical-align:middle !important;
    height:auto;
    padding:2px 2px 0 2px;
    display: table-cell;
} 
</style>