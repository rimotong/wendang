<template>
  <div>
    <template v-for="menu in this.menuData">
      <el-submenu :key="menu.orgId" :index="menu.orgId.toString()" v-if="menu.organizationInfoVos">
          <template slot="title">
            <span slot="title">{{menu.orgName}}
              <label style="float:right;" v-if="menu.equipmentNumber">{{menu.onlineNumber}}/{{menu.equipmentNumber}}</label>
              <label style="float:right;" v-else-if="menu.onlineNumber">{{menu.onlineNumber}}</label>
            </span>
          </template>
          <menu-tree :menuData="menu.organizationInfoVos"></menu-tree>
      </el-submenu>
      <el-menu-item :key="menu.orgId" :index="menu.orgId.toString()" v-else @click="update(menu.videoAddress,menu.orgName,menu.bgDirectPlayId)">
          <span slot="title" >{{menu.orgName}}</span>
      </el-menu-item>
    </template>
  </div>
</template>
 
<script>
import {baseURLs} from "@/tools/network"
import { mapState,mapActions } from 'pinia'
import storeId  from '@/store'
export default {
  props: ['menuData'],
  name: 'MenuTree',
  computed: {
    ...mapState(storeId, ['numbers','VideoUrl4','VideoUrl9']),
  },
  methods: {
    ...mapActions(storeId, ['VideoUrl','virtualVideoId','ImgName']),
    update(data,name,buildId){
      const store = storeId()
      store.$patch((state) => {
        if(this.numbers==1){
          state.VideoUrl = data
          state.ImgName = name
          state.virtualVideoId = buildId
        }
        if(this.numbers==4){
          if(this.VideoUrl4.length==4){
            if(this.VideoUrl4.findIndex(item=>{return item.id==buildId})>-1){
              this.$message.warning("视频源重复")
            }else{
            state.VideoUrl4.shift()
            state.VideoUrl4.push({
              src: `${baseURLs}/live/${window.btoa(data)}/live.flv`,
              recordUrl:data,
              id: buildId,
              name:name,
              isLoading: false,
              isLoaded:false,
              isShowControl: false,
              show:true,
              currentDuration: "0",
            })
            }
          }
          else if(this.VideoUrl4.length<4){
            if(this.VideoUrl4.length==0){
              state.VideoUrl4.push({
                src: `${baseURLs}/live/${window.btoa(data)}/live.flv`,
                recordUrl:data,
                id: buildId,
                name:name,
                isLoading: false,
                isLoaded:false,
                isShowControl: false,
                show:true,
                currentDuration: "0",
              })
            }else{
              if(this.VideoUrl4.findIndex(item=>{return item.id==buildId})>-1){
                this.$message.warning("视频源重复")
              }else{
                state.VideoUrl4.push({
                  src: `${baseURLs}/live/${window.btoa(data)}/live.flv`,
                  recordUrl:data,
                  id: buildId,
                  name:name,
                  isLoading: false,
                  isLoaded:false,
                  isShowControl: false,
                  show:true,
                  currentDuration: "0",
                })
              }
            }
          }
        }
        if(this.numbers==9){
          if(this.VideoUrl9.length==9){
            if(this.VideoUrl9.findIndex(item=>{return item.id==buildId})>-1){
              this.$message.warning("视频源重复")
            }else{
            state.VideoUrl9.shift()
            state.VideoUrl9.push({
              src: `${baseURLs}/live/${window.btoa(data)}/live.flv`,
              recordUrl:data,
              id: buildId,
              name:name,
              isLoading: false,
              isLoaded:false,
              isShowControl: false,
              show:true,
              currentDuration: "0",
            })
            }
          }
          else if(this.VideoUrl9.length<9){
            if(this.VideoUrl9.length==0){
              state.VideoUrl9.push({
                src: `${baseURLs}/live/${window.btoa(data)}/live.flv`,
                recordUrl:data,
                id: buildId,
                name:name,
                isLoading: false,
                isLoaded:false,
                isShowControl: false,
                show:true,
                currentDuration: "0",
              })
            }else{
              if(this.VideoUrl9.findIndex(item=>{return item.id==buildId})>-1){
                this.$message.warning("视频源重复")
              }else{
                state.VideoUrl9.push({
                  src: `${baseURLs}/live/${window.btoa(data)}/live.flv`,
                  recordUrl:data,
                  id: buildId,
                  name:name,
                  isLoading: false,
                  isLoaded:false,
                  isShowControl: false,
                  show:true,
                  currentDuration: "0",
                })
              }
            }
          }
        }
      })
    }
  }
}
</script>