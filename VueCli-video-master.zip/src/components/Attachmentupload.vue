<template>
  <div class="Attachment_upload">
    <div v-if="disabled" class="requirement_box_enclosure">
      <span>上传附件</span>
    </div>
    <div v-else class="requirement_box_enclosure" @click="dialogVisible = true">
      <span>上传附件</span>
      <img src="@/assets/imges/upload.png" alt="" style="cursor: pointer" />
    </div>
    <div class="dialog">
        <span
          slot="title"
          style="
            margin-right: 80%;
            font-size: 18px;
            font-family: 'Roboto Bold', 'Roboto', 'Roboto Bold', 'Roboto'-700;
            font-weight: bold;
            text-align: left;
            color: #002f75;
            line-height: 18px;
          "
          >上传附件</span
        >
        <span class="text_content">
          <div>
            <span class="large_txt">新增附件</span><i></i
            ><span class="Small_txt"
              >支持上传word、excel、pdf、压缩包等文件格式，且文件大小不得超过10
              M</span
            >
          </div>
          <div>
            <el-upload
              class="upload-demo"
              ref="upload"
              action="doUpload"
              :limit="10"
              :file-list="fileList"
              :before-upload="beforeUpload"
              multiple
              :on-exceed="handleExceed"
              enctype="multipart/form-data"
            >
              <div class="Selection_box">
                <p>请选择附件</p>
                <span class="el-icon-more"></span>
              </div>
              <div class="" slot="tip">
                <span class="large_txt">附件说明</span>
                <el-input
                  type="textarea"
                  :rows="2"
                  placeholder="请输入（400字內）"
                  maxlength="400"
                  v-model="textareas"
                >
                </el-input>
              </div>
              <div slot="tip">
                <span class="large_txt">已选附件</span><i></i
                ><span class="Small_txt">单次上传限制10个附件</span>
              </div>
              <ul slot="tip" class="fill_box">
                <li v-for="(item, index) in fill_number[listNum]" :key="item">
                  <span class="fill_text">{{ item }}</span
                  ><span class="delete" @click="deletes(index)">删除</span>
                </li>
              </ul>
            </el-upload>
          </div>
        </span>
    </div>
  </div>
</template>
<script>
import zh from "../assets/api/langs/zh";
export default {
  props:{
    fill_arry:{
      type:[Array],
      default: () => [],
    },
    disabled:{
      type:Boolean,
      default:false
    },
    state: {
      type:Number,
      default:0
    }
  },
  components: {},
  data() {
    return {
      fileNamess:null,
      fill_number:null,
    };
  },
  watch: {
    fileslists: {
      handler(val) {
        this.$emit('updates', this.fileNamess,this.fileslists,this.fill_arry)
      },
      deep: true, // 深度监听
    }
  },
  methods: {
    // render 事件
    renderHeader(h, { column }) {
      // h即为cerateElement的简写，具体可看vue官方文档
      return h("div", {
        attrs: {
          class: "cell",
        },
        domProps: {
          innerHTML: '<span style="color:red">*&nbsp;</span>' + column.label,
        },
      });
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 10 个文件，本次选择了 ${files.length} 个文件，共选择了 ${
          files.length + fileList.length
        } 个文件`
      );
    },
    beforeUpload(file) {
      const extension = file.name.split(".").pop() === "txt";
      const extension2 = file.name.split(".").pop() === "doc";
      const extension3 = file.name.split(".").pop()=== "xls";
      const extension4 = file.name.split(".").pop()=== "xlsx";
      const extension5 = file.name.split(".").pop()=== "docx";
      const extension6 = file.name.split(".").pop()=== "pdf";
      const isLt10M = file.size / 1024 / 1024 < 10;
      if (
        !extension &&
        !extension2 &&
        !extension3 &&
        !extension4 &&
        !extension5 &&
        !extension6 
      ) {
        this.$message.warning(
          "上传模板只能是 txt、doc、xls、xlsx、docx、pdf格式!"
        );
        return;
      }
      if (!isLt10M) {
        this.$message.warning("上传模板大小不能超过 10MB!");
        return;
      }
      this.fileName = file.name;
      this.fileNamess[this.listNum].push(file.name);
      this.fill_number[this.listNum] = this.fileNamess[this.listNum];
      // this.fileNamess = [];
      this.name = this.fileNamess[this.listNum];
      this.id = file.uid;
      if(this.fill_number[this.fill_number.length-1].length == 0 && this.fileNamess[this.fileNamess.length-1].length == 0){
        this.fill_number.pop();
        this.fileNamess.pop();
        this.fileslists.pop();
      }
      return false; // 返回false不会自动上传
    },
    getval() {
      // ("vals", this.vass);
      var ch = zh.simplized(this.vass);
      var ch2 = zh.traditionalized(this.vass);
      // ("简", ch);
      // ("繁", ch2);
    },
  },
  mounted() {},
  updated() {},
};
</script>

<style lang="scss" scoped>
.requirement_box_enclosure {
  width: 95px;
  margin-left: 64px;
  display: flex;
  justify-content: left;
  align-items: center;
  span {
    margin-right: 10px;
  }
  img {
    width: 14px;
    height: 13px;
    // margin-right: 220px;
  }
}
.Selection_box {
  width: 300px;
  height: 32px;
  border: 1px solid #d7d7d7;
  border-radius: 5px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 21px 0;
  padding: 0 10px;
  box-sizing: border-box;
  p {
    color: #cccccc;
  }
}
::v-deep .el-upload-list {
  display: none !important;
}
.fill_box {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  li {
    margin: 17px 32px 21px 0;
    list-style: none;
    .fill_text {
      font-size: 14px;
      color: #409eff;
    }
    .delete {
      color: #f56c6c;
      font-size: 14px;
      margin-left: 17px;
      cursor: pointer;
    }
  }
}
.dialog {
  text-align: left;
  ::v-deep .el-dialog__wrabrander {
    left: 15%;
  }
  ::v-deep .el-button {
    width: 140px;
    height: 40px;
    color: #002f75;
  }
  ::v-deep .el-button--primary {
    background: #002f75;
    color: #ffffff;
  }
  .text_content {
    display: block;
    margin: 32px 64px;
    font-size: 14px;
    font-family: "Roboto", "Roboto"-400;
    font-weight: 400;
    line-height: 14px;
    i {
      display: inline-block;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: #f88b1b;
      margin: 0 5px 0 10px;
    }
    .large_txt {
      font-size: 16px;
      font-family: "Roboto", "Roboto"-400;
      font-weight: 400;
      text-align: left;
      line-height: 16px;
    }
    .Small_txt {
      font-size: 12px;
      font-family: "Roboto", "Roboto"-400;
      font-weight: 400;
      text-align: left;
      color: #999999;
      line-height: 12px;
    }
    ::v-deep .el-textarea__inner {
      height: 148px;
      margin: 16px 0 30px 0;
    }
  }
  ::v-deep .el-dialog__footer {
    text-align: center;
    button {
      margin-right: 11px;
    }
  }
}
</style>