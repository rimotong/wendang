<template>
  <div class="trnavs">
    <div class="trnav">
      <div class="trnav_rt">
        <!-- <img class="logo" src="@/assets/imges/fii.png" /> -->
        <span style="color:antiquewhite;opacity: 0.8;">生产安全隐患远程稽核</span>
      </div>
      <ul class="menu">
        <li class="li" :class="this.pageflag==true&&this.indexs==1?'lis':''" @click="Gopage(1)">稽核直播</li>
        <li class="li" :class="this.pageflag==true&&this.indexs==2?'lis':''" @click="Gopage(2)">虚拟房间</li>
        <li class="li" :class="this.pageflag==true&&this.indexs==3?'':''" @click="Gopage(3)">
          <Dropdown @change="change" :dplLable="dplLable" :dataList="dataList"></Dropdown>
        </li>
        <!-- <li class="li" :class="this.pageflag==true&&this.indexs==4?'':''" @click="Gopage(4)">
          <Dropdown @change="change" :dplLable="dplLables" :dataList="Auditplan"></Dropdown>
        </li> -->
        <li class="li" :class="this.pageflag==true&&this.indexs==5?'lis':''" @click="Gopage(5)">设备管理</li>
        <li class="li" :class="this.pageflag==true&&this.indexs==6?'':''"  @click="Gopage(6)">
          <Dropdown @change="change"></Dropdown>
        </li>
      </ul>
      <div class="trnav_lf">
        <!-- <img
          v-if="text_state"
          src="@/assets/imges/simple.png"
          @click="onSwitchLanguage"
          alt=""
        />
        <img
          v-else
          src="@/assets/imges/Multiply.png"
          @click="onSwitchLanguage"
          alt=""
        /> -->
        <div  class="font"><label>稽核人<br />F1300257  王芳</label></div>
        <img src="@/assets/img/头像.png" alt="" />
      </div>
      <!-- <div></div> -->
    </div>
  </div>
</template>

<script>
// import { getlogout } from "../tools/index"
import Dropdown from "../post.vue"
export default {
  name: "Home",
  components: {
    Dropdown
  },
  data() {
    return {
      dataList:[{name: "直播证据",path:"/livescreenshot"},
                {name: "虚拟房间证据",path:"/roomscreenshot"},],
      Auditplan:[{name: "稽核计划列表",path:"/auditlist"},
                {name: "稽核计划审核",path:"/audit"},],
      dplLable:"稽核证据",
      dplLables:"稽核计划",
      activeIndex: "1",
      activeIndex2: "1",
      text_state: true,
      indexs: 1,
      show:false,
      pageflag:true,
      pagelist:{
        indexs:1,
        pageflag:true
      },
    };
  },
  created(){
    this.pagelist = JSON.parse(decodeURIComponent(window.atob(sessionStorage.getItem("pagelist"))))
    this.indexs=this.pagelist.indexs;
    this.pageflag=this.pagelist.pageflag;
  },
  methods: {
    change(val){
      this.$router.push(val.value.path)
    },
    Gopage(index) {
      this.indexs=index;
      this.pageflag=false;
      if (index == 1) {
        this.$router.push("/");
        this.pageflag=true;
      } else if (index == 2) {
        this.$router.push("/room");
        this.pageflag=true
      } else if (index == 3) {
        this.pageflag=true
      } else if (index == 4) {
        this.pageflag=true
      } else if (index == 5) {
        this.$router.push("/device");
        this.pageflag=true
      } else if (index == 6) {
        this.pageflag=true
      }
      this.pagelist.indexs=this.indexs;
      this.pagelist.pageflag=this.pageflag;
      sessionStorage.setItem('pagelist', window.btoa(window.encodeURIComponent(JSON.stringify(this.pagelist))))
    },
    // 语言切换
    onSwitchLanguage(val) {
      this.lang = val;
      this.text_state = !this.text_state;
      if (this.text_state) {
        //简体
        localStorage.setItem("lang", "s");
      } else {
        localStorage.setItem("lang", "t");
      }
      this.$zh_tran(localStorage.getItem("lang"));
    },
    //退出登录
    Btnbreak(){
      // setTimeout(window.location.replace(`http://10.124.131.79/#/login` + window.location.host), 2000);
    }
  },
};
</script>
<style lang="scss">
.trnavs {
  background: linear-gradient(180deg, rgba(13, 55, 116, 1) 0%, rgba(0, 0, 0, 1) 100%);
  text-align: center;
  .trnav {
    width: 100%;
    height: 80px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0px 1px 2px 0px rgba($color: #000000, $alpha: 0.16);
    .trnav_rt {
      height: 80px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .logo {
        width: 136px;
        height: 32px;
        margin-left: 42px;
      }
      span {
        height: 33px;
        font-size: 25px;
        font-family: Roboto, Roboto-Bold;
        font-weight: 700;
        text-align: left;
        color: #ffffff;
        margin-left: 13px;
      }
    }
    .menu {
      width: 60%;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .li {
        list-style: none;
        font-size: 18px;
        color:rgb(206, 206, 206);
        font-weight: 700;
        cursor: pointer;
        padding: 0 20px;
        height: 72px;
        line-height: 72px;
        span{
          color: rgb(206, 206, 206);
          font-size: 18px;
        }
      }
    }
    .lis{
      border-bottom: 8px solid #ffffff;
    }
    .dropdown{
      width: 500px;
      .item{
        width: 100%;
      }
    }
    .trnav_lf {
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      .font{
        padding-bottom: 10px;
        color: #ffffff;
      }
      img {
        width: 60px;
        height: 60px;
        border-radius:50%;
        cursor: pointer;
        padding-right: 10px;
      }
      // div {
      //   width: 52px;
      //   height: 52px;
      //   background: #002f75;
      //   border-radius: 50%;
      //   margin: 10px 20px;
      // }
      span {
        color: #ffffff;
        font-size: 14px;
        margin-right: 31px;
        cursor: pointer;
      }
    }
  }
  .logo {
    width: 136px;
    height: 32px;
    margin-left: 42px;
  }
}
</style>

