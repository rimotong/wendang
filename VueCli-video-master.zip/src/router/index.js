import Vue from 'vue'
import VueRouter from 'vue-router'
// import Home from '../views/Home.vue'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: '首页',
    component:() => import('../views/home/home.vue'),
    children:[
      {
        path:'/video',
        component:() => import('../components/flv.vue'),
      },
      {
        path:'/video4',
        component:() => import('../views/home/componenrs/videos4.vue'),
      },
      {
        path:'/video9',
        component:() => import('../views/home/componenrs/videos9.vue'),
      },
    ],
  },
  {
    path: '/user',
    name: '用户管理',
    component:() => import('../views/System/user.vue'),
  },
  {
    path: '/area',
    name: '区域管理',
    component:() => import('../views/System/area.vue'),
  },
  {
    path: '/areabak',
    name: '区域',
    component:() => import('../views/System/areabak.vue'),
  },
  // {
  //   path: '/role',
  //   name: '角色管理',
  //   component:() => import('../views/System/Role.vue'),
  //   children:[
  //     {
  //       path:'/information',
  //       component:() => import('../views/System/components/Role/information.vue'),
  //     },
  //   ],
  //   redirect:'/information'
  // },
  {
    path: '/livescreenshot',
    name: '直播截图',
    component:() => import('../views/evidence/LiveScreenshot.vue'),
  },
  {
    path: '/roomscreenshot',
    name: '虚拟房间截图',
    component:() => import('../views/evidence/RoomScreenshot.vue'),
  },
  {
    path: '/audit',
    name: '稽核计划审核',
    component:() => import('../views/Auditplan/audit.vue'),
  },
  {
    path: '/auditlist',
    name: '稽核计划列表',
    component:() => import('../views/Auditplan/auditlist.vue'),
  },
  {
    path: '/room',
    name: '需求管理',
    component:() => import('../views/room/room.vue'),
    children: [
      {
        path: "/index1",
        component: () => import("../views/room/components/Breadcrumb/index1.vue"),
        meta: {
          requireAuth: true,
        },
      },
      {
        path: "/index2",
        name: "index2",
        component: () => import("../views/room/components/Breadcrumb/index2.vue"),
        meta: {
          requireAuth: true,
          breadNumber: 2,
        },
      },
      {
        path: "/index3",
        name: "index3",
        component: () => import("../views/room/components/Breadcrumb/index3.vue"),
        meta: {
          requireAuth: true,
          breadNumber: 3,
        },
      },
      {
        path: "/index4",
        name: "index4",
        component: () => import("../views/room/components/Breadcrumb/index4.vue"),
        meta: {
          requireAuth: true,
          breadNumber: 4,
        },
      },
      {
        path: "/index5",
        name: "index5",
        component: () => import("../views/room/components/Breadcrumb/index5.vue"),
        meta: {
          requireAuth: true,
          breadNumber: 5,
        },
      },
    ],
    redirect:'/index1'
  },
  {
  path: '/purchase',
    name: '采购管理',
    component: () => import('../views/Ring.vue')
  },
  {
    path: '/device',
    name: '报表管理',
    component: () => import('../views/device/device.vue')
  },
  {
    path: '/system',
    name: '供应商管理', 
    component: () => import('../views/Mine.vue')
  }
]

const router = new VueRouter({
  routes
})
const VueRouterPush = VueRouter.prototype.push
VueRouter.prototype.push = function push (to) {
  return VueRouterPush.call(this, to).catch(err => err)
}
export default router
