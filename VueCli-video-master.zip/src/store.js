import { defineStore } from 'pinia'

export default defineStore('storeId', {
  // arrow function recommended for full type inference
  state: () => {
    return {
      Business:sessionStorage.getItem("Business")||"",
      area:sessionStorage.getItem("area")||"",
      Factory:sessionStorage.getItem("Factory")||"",
      building:sessionStorage.getItem("building")||"",
      VideoUrl:"",
      record:false,
      virtualVideoUrl:"",
      virtualVideoId:"",
      recordId:"",
      fileId:"",
      ImgName:"",
      pid:0,
      numbers:1,
      VideoUrl4:[],
      VideoUrl9:[],
    }
  },
  actions: {  // 和vue中的methods一样
    updatePhone(newPhone) {
      this.Business = newPhone 
    },
    updateNumbers(newNumbers) {
      this.Numbers = newNumbers // 可以使用this访问和修改state中的数据
    },
  },
})